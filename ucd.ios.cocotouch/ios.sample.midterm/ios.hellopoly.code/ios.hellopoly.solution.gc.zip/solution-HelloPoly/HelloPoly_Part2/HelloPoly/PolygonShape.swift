//
//  PolygonShape.swift
//  HelloPoly
//
//  Created by Me on 10/01/2019.
//  Copyright © 2019 UCD. All rights reserved.
//

import UIKit

protocol PolygonProtocol {
    func pointsInRect(_ rect: CGRect) -> [CGPoint]
}

class PolygonShape: NSObject, PolygonProtocol {
    private let names = ["Triangle", "Square", "Pentagon", "Hexagon", "Heptagon", "Octagon", "Nonagon", "Decagon", "Hendecagon", "Dodecagon"]
    
    var numberOfSides: Int = 8 {
        didSet {
            if !(3...12).contains(numberOfSides) {
                if oldValue <= 3 {
                    numberOfSides = 3
                } else {
                    numberOfSides = 12
                }
            }
        }
    }
    
    var name: String {
        get {
            return names[numberOfSides - 3]
        }
    }
    
    override var description: String {
        return name
    }
    
    func pointsInRect(_ rect: CGRect) -> [CGPoint] {
        let center = rect.center
        let radius = min(rect.size.width, rect.size.height) / 2.0
        let arc = 2 * CGFloat.pi / CGFloat(numberOfSides)
        
        var vertexArray = [CGPoint]()
        for i in 0..<numberOfSides {
            var vertex = center
            vertex.x += cos(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
            vertex.y += sin(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
            vertexArray.append(vertex)
        }
        return vertexArray
    }
    
}



var polygonPoints = { (rect: CGRect, numberOfSides: Int) -> [CGPoint] in
    let center = rect.center
    let radius = min(rect.size.width, rect.size.height) / 2.0
    let arc = 2 * CGFloat.pi / CGFloat(numberOfSides)
    
    var vertexArray = [CGPoint]()
    for i in 0..<numberOfSides {
        var vertex = center
        vertex.x += cos(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
        vertex.y += sin(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
        vertexArray.append(vertex)
    }
    return vertexArray
}



extension CGRect {
    var center: CGPoint {
        get {
            return CGPoint(x: size.width / 2.0 + origin.x, y: size.height / 2.0 + origin.y)
        }
    }
}

