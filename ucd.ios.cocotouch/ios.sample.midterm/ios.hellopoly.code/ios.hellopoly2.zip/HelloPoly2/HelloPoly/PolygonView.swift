
import UIKit

class PolygonView: UIView {
  var delegate: PolygonProtocol?

  override func draw(_: CGRect) {}

  func drawRect(rect: CGRect) {
    let shape = CAShapeLayer()
    layer.addSublayer(shape)
    shape.opacity = 0.5
    shape.name = "polygon"
    shape.lineWidth = 2
    shape.lineJoin = CAShapeLayerLineJoin.miter
    shape.strokeColor = UIColor(hue: 0.786, saturation: 0.79, brightness: 0.53, alpha: 1.0).cgColor
    shape.fillColor = UIColor(hue: 0.786, saturation: 0.15, brightness: 0.89, alpha: 1.0).cgColor

    let path = UIBezierPath()

    for (index, point) in delegate!.pointsInRect(rect: rect).enumerated() {
      if index == 0 {
        path.move(to: point)
      } else {
        path.addLine(to: point)
      }
    }

    path.close()
    shape.path = path.cgPath
  }
}
