
import UIKit

class PolygonVC: UIViewController {
  // SCREEN LABELS
  @IBOutlet var sidesLbl: UILabel!
  @IBOutlet var decreaseBtn: UIButton!
  @IBOutlet var increaseBtn: UIButton!

  // POLYGON VIEW WITH CUSTOM CLASS TYPE
  @IBOutlet var polygonView: PolygonView!

  // POLYGON SHAPE INSTANCE
  var polygon = PolygonShape()

  // POLYGON FRAME FOR THE SCREEN.
  var polygonFrame: CGRect?

  // CONSTANTS AND KET VALUES
  var MIN_SIDES = 3
  var MAX_SIDES = 12
  var SIDES_KEY = "sides"

  override func viewDidLoad() {
    super.viewDidLoad()

    polygonFrame = CGRect(x: polygonView.center.x / 2, y: polygonView.center.y / 3, width: 100, height: 100)
    polygonView.delegate = polygon

    let defaults = UserDefaults.standard
    let sides = defaults.integer(forKey: SIDES_KEY)
    if sides != 0 { polygon.numberOfSides = sides }

    drawPolygon()
    checkBtnState()

    let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(decreaseSide))
    swipeLeft.direction = .left
    view.addGestureRecognizer(swipeLeft)

    let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(increaseSide))
    swipeRight.direction = .right
    view.addGestureRecognizer(swipeRight)
  }

  func drawPolygon() {
    let defaults = UserDefaults.standard
    defaults.set(polygon.numberOfSides, forKey: SIDES_KEY)
    _ = polygonView.layer.sublayers?.popLast()
    polygonView.drawRect(rect: polygonFrame!)
    sidesLbl.text = String(polygon.numberOfSides)
  }

  @IBAction func decreaseSide(_: Any) {
    if polygon.numberOfSides > MIN_SIDES {
      polygon.numberOfSides -= 1
    }
    checkBtnState()
    drawPolygon()
  }

  @IBAction func increaseSide(_: Any) {
    if polygon.numberOfSides < MAX_SIDES {
      polygon.numberOfSides += 1
    }
    checkBtnState()
    drawPolygon()
  }

  func checkBtnState() {
    if polygon.numberOfSides > MIN_SIDES { decreaseBtn.isEnabled = true
    } else { decreaseBtn.isEnabled = false
    }

    if polygon.numberOfSides < MAX_SIDES { increaseBtn.isEnabled = true
    } else { increaseBtn.isEnabled = false
    }
  }
}
