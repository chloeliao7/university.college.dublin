
import CoreGraphics
import Foundation

protocol PolygonProtocol {
  func pointsInRect(rect: CGRect) -> [CGPoint]
}

class PolygonShape: PolygonProtocol {
  public var numberOfSides: Int = 6
  public var name: String = "name"

  func pointsInRect(rect: CGRect) -> [CGPoint] {
    let center = rect.center
    let radius = min(rect.size.width, rect.size.height)
    let arc = 2 * CGFloat.pi / CGFloat(numberOfSides)

    var vertexArray = [CGPoint]()

    for i in 0 ..< numberOfSides {
      var vertex = center
      vertex.x += cos(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
      vertex.y += sin(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
      vertexArray.append(vertex)
    }
    return vertexArray
  }
}

extension CGRect {
  var center: CGPoint { return CGPoint(x: centerX, y: centerY) } // COR OF THE RECTANGLE CENTER

  var centerX: CGFloat { // RETURNS THE XCORD OF THE CENTER
    get { return midX }
    set { origin.x = newValue - width * 0.5 }
  }

  var centerY: CGFloat { // THE Y-COORDINATE = RECTANGLES CENTER -> NOTE: ACTS AS A SETTABLE MIDY -> RETURNS: THE Y-COORDINATE OF THE CENTER
    get { return midY }
    set { origin.y = newValue - height * 0.5 }
  }
}
