

import CoreGraphics
import Foundation

protocol PolygonProtocol {
  func pointsInRect(rect: CGRect) -> [CGPoint]
}

class PolygonShape: PolygonProtocol {
  public var numberOfSides: Int = 6
  public var name: String = "name"

  // CALCULATE THE POINTS IN A RECTANGLE TO MAKE THE POLYGON.
  func pointsInRect(rect: CGRect) -> [CGPoint] {
    let center = rect.center
    let radius = min(rect.size.width, rect.size.height)
    let arc = 2 * CGFloat.pi / CGFloat(numberOfSides)

    var vertexArray = [CGPoint]()
    for i in 0 ..< numberOfSides {
      var vertex = center
      vertex.x += cos(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
      vertex.y += sin(arc * CGFloat(i) - 2 * CGFloat.pi) * radius
      vertexArray.append(vertex)
    }

    return vertexArray
  }
}

extension CGRect {
  // THE COORDINATES OF THE RECT CENTER
  var center: CGPoint { return CGPoint(x: midX, y: midY) }
}
