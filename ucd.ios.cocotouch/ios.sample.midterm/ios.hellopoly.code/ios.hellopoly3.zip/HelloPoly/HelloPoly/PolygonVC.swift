

import UIKit

class PolygonVC: UIViewController {
  // SCREEN LABELS
  @IBOutlet var sidesLbl: UILabel!
  @IBOutlet var decreaseBtn: UIButton!
  @IBOutlet var increaseBtn: UIButton!

  // POLYGON VIEW WITH CUSTOM CLASS TYPE
  @IBOutlet var polygonView: PolygonView!

  // POLYGON SHAPE INSTANCE
  var polygon = PolygonShape()

  // POLYGON FRAME FOR THE SCREEN.
  var polygonFrame: CGRect?

  // CONSTANTS AND KET VALUES
  var MIN_SIDES = 3
  var MAX_SIDES = 12
  var SIDES_KEY = "sides"

  override func viewDidLoad() {
    super.viewDidLoad()

    // SETTING FRAME FOR THE POLYGON
    polygonFrame = CGRect(x: polygonView.center.x / 2, y: polygonView.center.y / 3, width: 100, height: 100)

    // SETTING DELEGATE IN POLYGONVIEW TO THE POLYGON INSTANCE OF POLYGONSHAPE BECAUSE THE POLYGONSHAPE CONFORMS TO THE PROTOCOL.
    polygonView.delegate = polygon

    // CHECKING IF THE USER DEFAULT HAS ANY PREVIOUS VALUE FOR NUMBEROFSIDES
    let defaults = UserDefaults.standard
    let sides = defaults.integer(forKey: SIDES_KEY)
    if sides != 0 {
      polygon.numberOfSides = sides
    }

    drawPolygon()

    checkBtnState()

    // LEFT AND RIGHT GESTUERS.
    let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(decreaseSide))
    swipeLeft.direction = .left
    view.addGestureRecognizer(swipeLeft)

    let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(increaseSide))
    swipeRight.direction = .right
    view.addGestureRecognizer(swipeRight)
  }

  @IBAction func decreaseSide(_: Any) {
    if polygon.numberOfSides > MIN_SIDES {
      polygon.numberOfSides -= 1
    }
    checkBtnState()
    drawPolygon()
  }

  @IBAction func increaseSide(_: Any) {
    if polygon.numberOfSides < MAX_SIDES {
      polygon.numberOfSides += 1
    }
    checkBtnState()
    drawPolygon()
  }

  func checkBtnState() {
    // CHECKING STATUS IF THE TOTAL SIDES ARE BETWEEN 3 - 12
    if polygon.numberOfSides > MIN_SIDES {
      decreaseBtn.isEnabled = true
    } else {
      decreaseBtn.isEnabled = false
    }

    if polygon.numberOfSides < MAX_SIDES {
      increaseBtn.isEnabled = true
    } else {
      increaseBtn.isEnabled = false
    }
  }

  func drawPolygon() {
    // SAVING THE SIDES IN THE APP SO IT SAVES THE STATE FOR NEXT STARTUP
    let defaults = UserDefaults.standard
    defaults.set(polygon.numberOfSides, forKey: SIDES_KEY)

    // REMOVE PREVIOUS POLYGON LAYER
    _ = polygonView.layer.sublayers?.popLast()

    polygonView.drawRect(rect: polygonFrame!)

    sidesLbl.text = String(polygon.numberOfSides)
  }
}
