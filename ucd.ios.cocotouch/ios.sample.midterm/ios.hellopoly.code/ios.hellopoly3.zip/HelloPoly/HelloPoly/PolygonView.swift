
import UIKit

class PolygonView: UIView {
  // DELEGATE FOR
  var delegate: PolygonProtocol?

  override func draw(_: CGRect) {}

  // DRAW RECT METHOD TO CRAETE THE POLYGON.
  func drawRect(rect: CGRect) {
    
    // CREATE A SHAPE AND ADD IT AS A SUBLAYER OF THE VIEW
    let shape = CAShapeLayer()
    layer.addSublayer(shape)

    // SHAPE SETTINGS AND COLOR
    shape.opacity = 0.5
    shape.lineWidth = 2
    shape.lineJoin = CAShapeLayerLineJoin.miter
    shape.strokeColor = UIColor(hue: 0.786, saturation: 0.79, brightness: 0.53, alpha: 1.0).cgColor
    shape.fillColor = UIColor(hue: 0.786, saturation: 0.15, brightness: 0.89, alpha: 1.0).cgColor

    // PATH OF THE POLYGON
    let path = UIBezierPath()

    for (index, point) in delegate!.pointsInRect(rect: rect).enumerated() {
      if index == 0 {
        path.move(to: point)
      } else {
        path.addLine(to: point)
      }
    }

    path.close()
    shape.path = path.cgPath
  }
}
