//
//  ViewController.swift
//  HelloPoly
//
//  Created by Me on 10/01/2019.
//  Copyright © 2019 UCD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var decreaseButton: UIButton!
    @IBOutlet weak var increaseButton: UIButton!
    @IBOutlet weak var vertexCountLabel: UILabel!
    @IBOutlet weak var polygonNameLabel: UILabel!
    
    lazy var polygonModel: PolygonShape = {
        let polygon = PolygonShape()
        polygon.numberOfSides = 8
        return polygon
    }()
    
    @IBAction func increaseSides(_ sender: UIButton) {
        polygonModel.numberOfSides += 1
        updateUI()
    }
    
    @IBAction func decreaseSides(_ sender: UIButton) {
        polygonModel.numberOfSides -= 1
        updateUI()
    }
    
    private func updateUI() {
        polygonNameLabel.text = polygonModel.name
        vertexCountLabel.text = "\(polygonModel.numberOfSides)"
        decreaseButton.isEnabled = polygonModel.numberOfSides == 3 ? false : true
        increaseButton.isEnabled = polygonModel.numberOfSides == 12 ? false : true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
