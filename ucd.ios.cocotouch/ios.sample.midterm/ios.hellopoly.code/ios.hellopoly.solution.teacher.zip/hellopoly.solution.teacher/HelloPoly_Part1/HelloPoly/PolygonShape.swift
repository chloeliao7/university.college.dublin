//
//  PolygonShape.swift
//  HelloPoly
//
//  Created by Me on 10/01/2019.
//  Copyright © 2019 UCD. All rights reserved.
//

import UIKit

class PolygonShape: NSObject {
    private let names = ["Triangle", "Square", "Pentagon", "Hexagon", "Heptagon", "Octagon", "Nonagon", "Decagon", "Hendecagon", "Dodecagon"]
    
    var numberOfSides: Int = 8 {
        didSet {
            if !(3...12).contains(numberOfSides) {
                if oldValue <= 3 {
                    numberOfSides = 3
                } else {
                    numberOfSides = 12
                }
            }
        }
    }
    
    var name: String {
        get {
            return names[numberOfSides - 3]
        }
    }
    
    override var description: String {
        return name
    }
}
