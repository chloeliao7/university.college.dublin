//
//  PolygonView.swift
//  HelloPoly
//
//  Created by Me on 10/01/2019.
//  Copyright © 2019 UCD. All rights reserved.
//

import UIKit

class PolygonView: UIView {
    var delegate: PolygonProtocol? = nil
    var lineWidth: Float = 2.0
    var strokeColor: UIColor = UIColor.blue
    var fillColor: UIColor = UIColor.green.withAlphaComponent(0.5)

    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        let insetRect = rect.insetBy(dx: CGFloat(lineWidth / 2.0), dy: CGFloat(lineWidth / 2.0))
        
        if let vertices = delegate?.pointsInRect(insetRect) {
            fillColor.setFill()
            strokeColor.setStroke()
            let path = UIBezierPath()
            path.move(to: vertices[0])
            for vertex in vertices[1..<vertices.count] {
                path.addLine(to: vertex)
            }
            path.close()
            path.stroke()
            path.fill()
            
        }
    }
}
