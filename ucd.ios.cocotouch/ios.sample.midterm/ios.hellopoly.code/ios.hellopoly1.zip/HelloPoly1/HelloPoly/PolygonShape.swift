
import CoreGraphics
import Foundation

class PolygonShape {
  public var numberOfSides: Int = 3
  public var name: String = "name"
}
