

import UIKit

class PolygonVC: UIViewController {
  @IBOutlet var mainlabel: UILabel!
  @IBOutlet var sidelabel: UILabel!
  @IBOutlet var decreaseBtn: UIButton!
  @IBOutlet var increaseBtn: UIButton!

  lazy var polygon = PolygonShape()

  var MIN_SIDES = 3
  var MAX_SIDES = 12

  override func viewDidLoad() {
    super.viewDidLoad()
    checkBtnState()

    let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(decreaseSide))
    swipeLeft.direction = .left
    view.addGestureRecognizer(swipeLeft)

    let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(increaseSide))
    swipeRight.direction = .right
    view.addGestureRecognizer(swipeRight)
  }

  @IBAction func decreaseSide(_: Any) {
    if polygon.numberOfSides > MIN_SIDES {
      polygon.numberOfSides -= 1
      sidelabel.text = String(polygon.numberOfSides)
    }
    checkBtnState()
  }

  @IBAction func increaseSide(_: Any) {
    if polygon.numberOfSides < MAX_SIDES {
      polygon.numberOfSides += 1
      sidelabel.text = String(polygon.numberOfSides)
    }
    checkBtnState()
  }

  func checkBtnState() {
    if polygon.numberOfSides > MIN_SIDES {
      decreaseBtn.isEnabled = true
    } else {
      decreaseBtn.isEnabled = false
    }

    if polygon.numberOfSides < MAX_SIDES {
      increaseBtn.isEnabled = true
    } else {
      increaseBtn.isEnabled = false
    }
  }
}
