//
//  ViewController.swift
//  GravityBubbles
//
//  Created by COMP47390 on 23/01/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIDynamicAnimatorDelegate {
    
    struct Constants {
        static let bubbleSize = CGSize(width: 28, height: 28)
    }

    @IBOutlet var gameView: BezierpathView!
    
    private var bubbleBehavior = BubbleBehavior()
    private lazy var animator: UIDynamicAnimator = {
        let animator = UIDynamicAnimator(referenceView: self.gameView)
        animator.addBehavior(self.bubbleBehavior)
        return animator
    }()
    
    
    private func dropBubble() {
        var frame = CGRect()
        frame.origin = CGPoint.zero
        frame.size = Constants.bubbleSize
        let x = gameView.bounds.width * CGFloat.random(in: 0..<1)
        frame.origin.x = x
        let bubbleView = EllipseView(frame: frame)
        bubbleBehavior.addBubble(bubbleView)
        lastDroppedView = bubbleView
    }
    
    private var lastDroppedView: UIView?
    private var attachement: UIAttachmentBehavior? {
        willSet {
            if attachement != nil {
                animator.removeBehavior(attachement!)
                gameView.setPath(nil, named: "attachement")
            }
        }
        didSet {
            if attachement != nil {
                animator.addBehavior(attachement!)
                attachement?.action = { [unowned self] in
                    if let attachementView = self.attachement?.items.first as? UIView {
                        let path = UIBezierPath()
                        path.move(to: self.attachement!.anchorPoint)
                        path.addLine(to: attachementView.center)
                        self.gameView.setPath(path, named: "attachement")
                    }
                }
            }
        }
    }
    
    @IBAction func grabBubble(_ sender: UIPanGestureRecognizer) {
        let point = sender.location(in: gameView)
        
        switch sender.state {
        case .began:
            if let viewToAttach = lastDroppedView {
                attachement = UIAttachmentBehavior(item: viewToAttach, attachedToAnchor: point)
                lastDroppedView = nil
            }
        case .ended:
            attachement = nil
        case .changed:
            attachement?.anchorPoint = point
        default:
            break
        }
    }
    
    
    @IBAction func tap(_ sender: UITapGestureRecognizer) {
        // print("\(sender.location(in: self.gameView))")
        dropBubble()
    }
    
    private func removeFullRow()
    {
        var bubblesToRemove = [UIView]()
        var bubbleFrame = CGRect(x: 0, y: gameView.frame.maxY, width: Constants.bubbleSize.width,height:Constants.bubbleSize.height)
        repeat {
            bubbleFrame.origin.y -= Constants.bubbleSize.height
            bubbleFrame.origin.x = 0
            var bubblesFound = [UIView]()
            var isRowFull = true
            for _ in 0 ..< Int(gameView.bounds.size.width / Constants.bubbleSize.width) {
                if let hitView = gameView.hitTest(CGPoint(x: bubbleFrame.midX, y: bubbleFrame.midY),with:nil) {
                    if hitView.superview == gameView {
                        bubblesFound.append(hitView)
                    } else {
                        isRowFull = false
                    }
                }
                bubbleFrame.origin.x += Constants.bubbleSize.width
            }
            if isRowFull {
                bubblesToRemove += bubblesFound
            }
        } while bubblesToRemove.count == 0 && bubbleFrame.origin.y > 0
        
        for bubble in bubblesToRemove {
            bubbleBehavior.removeBubble(bubble)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        animator.delegate = self
        let motionManager = (UIApplication.shared.delegate as! AppDelegate).motionManager
        if motionManager.isAccelerometerAvailable {
            motionManager.startAccelerometerUpdates(to: OperationQueue.main) { (data, _) in
                self.bubbleBehavior.gravity.gravityDirection = CGVector(dx: (data?.acceleration.x)!, dy: -(data?.acceleration.y)!)
            }
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        let motionManager = (UIApplication.shared.delegate as! AppDelegate).motionManager
        motionManager.stopAccelerometerUpdates()
    }
    
    func dynamicAnimatorDidPause(_ animator: UIDynamicAnimator) {
        print("In pause...")
        removeFullRow()
    }
    
    func dynamicAnimatorWillResume(_ animator: UIDynamicAnimator) {
        print("Animation resumed")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let barrierSize = CGSize(width: 80, height: 80)
        let barrierOrigin = CGPoint(x: gameView.bounds.midX - barrierSize.width / 2
            , y: gameView.bounds.midY - barrierSize.height / 2)
        let path = UIBezierPath(roundedRect: CGRect(origin: barrierOrigin, size: barrierSize), cornerRadius: min(barrierSize.height, barrierSize.width) / 5)
        bubbleBehavior.addBarrier(path, named: "square barrier")
        gameView.setPath(path, named: "square barrier")
    }
}

