//
//  ViewController.swift
//  Gallery
//
//  Created by COMP47390 on 26/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let imageName = segue.identifier!
        let destinationVC = segue.destination as? ImageVC
        destinationVC?.imageURL = URL(string: "https://www.leica-fotopark.com/pix/image/\(imageName)")
        destinationVC?.title = (sender as! UIButton).titleLabel?.text
    }

}

