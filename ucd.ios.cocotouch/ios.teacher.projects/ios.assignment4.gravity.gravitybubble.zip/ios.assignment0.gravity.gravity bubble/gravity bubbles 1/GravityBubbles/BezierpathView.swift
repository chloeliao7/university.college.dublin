//
//  BezierpathView.swift
//  GravityBubbles
//
//  Created by COMP47390 on 05/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class BezierpathView: UIView {
    private var bezierPaths = [String: UIBezierPath]()
    
    func setPath(_ path: UIBezierPath?, named name: String) {
        bezierPaths[name] = path
        setNeedsDisplay()
    }

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        for (_, path) in bezierPaths {
            path.stroke()
        }
    }
    

}
