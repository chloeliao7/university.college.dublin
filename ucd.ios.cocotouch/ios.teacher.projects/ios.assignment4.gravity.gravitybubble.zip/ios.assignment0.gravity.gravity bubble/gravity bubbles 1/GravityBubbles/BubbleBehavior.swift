//
//  BubbleBehavior.swift
//  GravityBubbles
//
//  Created by COMP47390 on 05/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class BubbleBehavior: UIDynamicBehavior {
    private var gravity = UIGravityBehavior()
    private lazy var collider: UICollisionBehavior = {
        let collider = UICollisionBehavior()
        collider.translatesReferenceBoundsIntoBoundary = true
        return collider
    }()
    private lazy var itemBehavior: UIDynamicItemBehavior = {
        let itemBehavior = UIDynamicItemBehavior()
        itemBehavior.elasticity = 0.8
        itemBehavior.allowsRotation = true
        return itemBehavior
    }()
    
    func addBarrier(_ path: UIBezierPath, named name: String) {
        collider.removeBoundary(withIdentifier: name as NSCopying)
        collider.addBoundary(withIdentifier: name as NSCopying, for: path)
    }
    
    override init() {
        super.init()
        addChildBehavior(gravity)
        addChildBehavior(collider)
        addChildBehavior(itemBehavior)
    }
    
    func addBubble(_ bubble: UIView) {
        dynamicAnimator?.referenceView?.addSubview(bubble)
        collider.addItem(bubble)
        gravity.addItem(bubble)
        itemBehavior.addItem(bubble)
    }
    
    func removeBubble(_ bubble: UIView) {
        gravity.removeItem(bubble)
        collider.removeItem(bubble)
        itemBehavior.removeItem(bubble)
        bubble.removeFromSuperview()
    }
}
