//
//  FlickrTVC.swift
//  FlickrPeek
//
//  Created by COMP47390 on 06/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class FlickrTVC: UITableViewController {
    private var photos = [[String: AnyObject]] () {
        didSet {
            if tableView.window != nil {
                tableView.reloadData()
            }
            print("\(photos.count)")
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return photos.count
    }
        
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dequeuedCell = tableView.dequeueReusableCell(withIdentifier: "FlickrCell", for: indexPath)
        let photo = photos[indexPath.row]
        dequeuedCell.detailTextLabel?.text = "\(photo[FlickrFetcher.FlickrAPI.FLICKR_PHOTO_OWNER]!)"
        dequeuedCell.textLabel?.text = "\(photo[FlickrFetcher.FlickrAPI.FLICKR_PHOTO_TITLE]!)"
        dequeuedCell.imageView?.image = #imageLiteral(resourceName: "ucd")
        if let url = FlickrFetcher.url(forPhoto: photo, format: .flickrPhotoFormatSquare) {
            FlickrFetcher.startFlickrFetch(url, completion: { (data) in
                print("fetching thumbnail for row: \(indexPath.row)")
                if let fetchData = data {
                    let image = UIImage(data: fetchData)
                    DispatchQueue.main.async {
                        dequeuedCell.imageView?.image = image
                        dequeuedCell.imageView?.contentMode = .scaleAspectFill
                    }
                }
            })
        }
        return dequeuedCell
    }
    
    private func fetchImages() {
        if let fetchUrl = FlickrFetcher.urlForRecentGeoreferencedPhotos() {
            FlickrFetcher.startFlickrFetch(fetchUrl, completion: { (data) in
                if let fetchData = data {
                    do {
                        let plistDict = try JSONSerialization.jsonObject(with: fetchData, options: []) as AnyObject
                        if let photos = plistDict.value(forKeyPath: FlickrFetcher.FlickrAPI.FLICKR_PHOTOS) as? [[String: AnyObject]] {
                            DispatchQueue.main.async { self.photos.insert(contentsOf: photos, at: 0) }
                        }
                    } catch { print("fetch failed: \((error as NSError).localizedDescription)") }
                }
            })
        }
    }    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        fetchImages()
    }

}

