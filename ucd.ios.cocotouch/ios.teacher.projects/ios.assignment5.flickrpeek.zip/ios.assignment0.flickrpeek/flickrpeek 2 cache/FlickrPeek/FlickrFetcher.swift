//
//  FlickrFetcher.swift
//  FlickrPeek
//
//  Created by Me on 16/02/2018.
//  Copyright © 2018 UCD. All rights reserved.
//

import Foundation
import CoreLocation

class FlickrFetcher {
    //FIXME: https://www.flickr.com/services/api/
    static let FlickrAPIKey = "REPLACE_WITH_YOUR_FLICKR_API_KEY"
    
    struct FlickrAPI {
        static let MAX_RESULT = 100
        static let FLICKR_PLACE_ID = "place_id"
        static let FLICKR_PLACE_NAME = "_content"
        static let FLICKR_TAG_NAME = "_content"
        static let FLICKR_PLACES = "places.place"
        static let FLICKR_TAGS = "tags.tag"
        static let FLICKR_PHOTOS = "photos.photo"
        static let FLICKR_PHOTO_OWNER = "ownername"
        static let FLICKR_PHOTO_ID = "id"
        static let FLICKR_PHOTO_DESCRIPTION = "description._content"
        static let FLICKR_PHOTO_TITLE = "title"
    }
    
    enum FlickrPhotoFormat: Int {
        case flickrPhotoFormatSquare = 1
        case flickrPhotoFormatLarge = 2
        case flickrPhotoFormatThumbnail = 3
        case flickrPhotoFormatSmall = 4
        case flickrPhotoFormatMedium500 = 5
        case flickrPhotoFormatMedium640 = 6
        case flickrPhotoFormatOriginal = 64
    }
    
    class func url(forQuery query: String) -> URL? {
        let urlQuery = "\(query)&format=json&nojsoncallback=1&api_key=\(FlickrFetcher.FlickrAPIKey)"
        return URL(string: urlQuery)
    }
    
    class func url(forPlaces location: CLLocationCoordinate2D) -> URL? {
        let apiString = "https://api.flickr.com/services/rest/?method=flickr.places.findByLatLon"
        let urlQuery = "\(apiString)&lat=\(location.latitude)&lon=\(location.longitude)&accuracy=6"
        return FlickrFetcher.url(forQuery: urlQuery)
    }
    
    class func url(forPlaces placeID: String) -> URL? {
        let apiString = "https://api.flickr.com/services/rest/?method=flickr.places.tagsForPlace"
        let urlQuery = "\(apiString)&place_id=\(placeID)&"
        return FlickrFetcher.url(forQuery: urlQuery)
    }
    
    class func urlForPhotos(inPlace placeID: String, tag: String) -> URL? {
        let apiString = "https://api.flickr.com/services/rest/?method=flickr.photos.search"
        let urlQuery = "\(apiString)&place_id=\(placeID)&tags=\(tag)&per_page=\(FlickrAPI.MAX_RESULT)&extras=original_format,tags,description,geo,date_upload,owner_name,place_url"
        return FlickrFetcher.url(forQuery: urlQuery)
    }
    
    
    class func url(forPhoto photo: [String: AnyObject], format: FlickrPhotoFormat) -> URL? {
        
        let photo_id = photo["id"]
        var secret = photo["secret"]
        var fileType = "jpg"
        
        if format == FlickrPhotoFormat.flickrPhotoFormatOriginal
        {
            secret = photo["originalsecret"]
            fileType = photo["originalformat"]! as! String
        }
        
        guard let farm = photo["farm"], let server = photo["server"], secret != nil else { return nil }
        
        var formatString = "s"
        switch format {
        case .flickrPhotoFormatSquare: formatString = "s"
        case .flickrPhotoFormatLarge: formatString = "b"
        case .flickrPhotoFormatThumbnail: formatString = "t"
        case .flickrPhotoFormatSmall: formatString = "m"
        case .flickrPhotoFormatMedium500: formatString = "-"
        case .flickrPhotoFormatMedium640: formatString = "z"
        case .flickrPhotoFormatOriginal: formatString = "o"
        }
        
        let urlQuery = "https://farm\(farm).static.flickr.com/\(server)/\(photo_id!)_\(secret!)_\(formatString).\(fileType)"
        return URL(string: urlQuery)
    }
    
    class func startFlickrFetch(_ url: URL, completion: @escaping (_ data: Data?) -> Void)
    {
        assert(FlickrFetcher.FlickrAPIKey != "REPLACE_WITH_YOUR_FLICKR_API_KEY", "EDIT API KEY IN FlickrFetcher")
        let request = URLRequest(url: url)
        let configuration = URLSessionConfiguration.ephemeral
        let session = URLSession(configuration: configuration)
        let task = session.downloadTask(with: request, completionHandler: { (location, response, error) -> Void in
            var data: Data?
            if error == nil {
                data = try? Data(contentsOf: location!)
            }
            completion(data)
        })
        task.resume()
    }
    
    class func urlForRecentGeoreferencedPhotos() -> URL? {
        let apiString = "https://api.flickr.com/services/rest/?method=flickr.photos.search"
        let urlQuery = "\(apiString)&per_page=500&license=1,2,4,7&has_geo=1&extras=original_format,tags,description,geo,date_upload,owner_name,place_url"
        return FlickrFetcher.url(forQuery: urlQuery)
    }
}
