//
//  ViewController.swift
//  RPNCalc
//
//  Created by COMP47390 on 23/01/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var calcDisplay: UILabel!
    
    private var inputMode = false
    private var stack = [Double]()
    
    var displayValue: Double {
        get {
            return NumberFormatter().number(from: calcDisplay.text!) as! Double
        }
        set {
            calcDisplay.text = "\(newValue)"
            inputMode = false
        }
    }
    
    @IBAction func digitPressed(_ sender: UIButton) {
        if let digit = sender.currentTitle {
            print("digit pressed = \(digit)")
            if inputMode {
                calcDisplay.text = calcDisplay.text! + digit
            } else {
                calcDisplay.text = digit
                inputMode = true
            }
        }
    }
    
    @IBAction func pushOperand(_ sender: UIButton?) {
        inputMode = false
        stack.append(displayValue)
        print(stack)
    }
    
    func performOperation(_ operation: (Double, Double) -> Double) {
        if stack.count >= 2 {
            displayValue = operation(stack.removeLast(), stack.removeLast())
            pushOperand(nil)
        }
    }
    
    func performOperation(_ operation: (Double) -> Double) {
        if stack.count >= 1 {
            displayValue = operation(stack.removeLast())
            pushOperand(nil)
        }
    }
    
    func multiply(_ op1: Double, _ op2: Double) -> Double {
        return op1 * op2
    }
    
    @IBAction func operationPressed(_ sender: UIButton) {
        let operation = sender.currentTitle!
        if inputMode {
            pushOperand(nil)
        }
        switch operation {
        case "+":
//            if stack.count >= 2 {
//                displayValue = stack.removeLast() + stack.removeLast()
//                pushOperand(nil)
//            }
            performOperation(+)
            break
        case "×":
            performOperation(multiply)
            break
        case "−":
            // performOperation({(op1, op2) in op2 - op1})
            performOperation({$1 - $0})
            break
        case "÷":
            performOperation({(op1: Double, op2: Double) -> Double in return op2 / op1})
            break
        case "±":
            performOperation() {-$0}
        default:
            break
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

