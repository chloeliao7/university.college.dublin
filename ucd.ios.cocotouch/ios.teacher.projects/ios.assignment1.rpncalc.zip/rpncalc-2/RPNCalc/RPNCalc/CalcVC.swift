//
//  CalcVC.swift
//  RPNCalc
//
//  Created by COMP47390 on 23/01/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class CalcVC: UIViewController {

    @IBOutlet weak var calcDisplay: UILabel!
    private var calcModel = CalcModel()
    private var inputMode = false
    
    var displayValue: Double {
        get {
            return NumberFormatter().number(from: calcDisplay.text!) as! Double
        }
        set {
            calcDisplay.text = "\(newValue)"
            inputMode = false
        }
    }
    
    @IBAction func digitPressed(_ sender: UIButton) {
        if let digit = sender.currentTitle {
            if inputMode {
                calcDisplay.text = calcDisplay.text! + digit
            } else {
                calcDisplay.text = digit
                inputMode = true
            }
        }
    }
    
    @IBAction func pushOperand(_ sender: UIButton?) {
        inputMode = false
        if let result = calcModel.pushOperand(displayValue) {
            displayValue = result
        } else {
            displayValue = 0
        }
    }
    

    @IBAction func operationPressed(_ sender: UIButton) {
        if inputMode {
            pushOperand(nil)
        }
        
        if let operation = sender.currentTitle {
            if let result = calcModel.performOperation(operation) {
                displayValue = result
            } else {
                displayValue = 0
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

