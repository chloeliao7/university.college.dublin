// Copyright © 2017 UCD. All rights reserved.

/* CITE: http://arxiv.org/abs/1709.06871
 
 Philip J. Corr, Guenole C. Silvestre, Chris J. Bleakley
 Open Source Dataset and Deep Learning Models for Online Digit Gesture Recognition on Touchscreens
 Irish Machine Vision and Image Processing Conference (IMVIP) 2017
 Maynooth, Ireland, 30 August-1 September 2017
 
 @inproceedings{1709.06871,
     Author     = {Philip J. Corr and Guenole C. Silvestre and Chris J. Bleakley},
     Title      = {Open Source Dataset and Deep Learning Models for Online Digit Gesture Recognition on Touchscreens},
     Booktitle  = {Irish Machine Vision and Image Processing Conference ({IMVIP}) 2017, Maynooth, Ireland, August 30--September 1, 2017},
     Year       = {2017},
     eprint     = {arXiv:1709.06871},
     url        = {http://arxiv.org/abs/1709.06871}
 }
 */
 
import UIKit
import CoreML
import UIKit.UIGestureRecognizerSubclass

class UCD_DigitGestureRecognizer: UIGestureRecognizer {
    @IBInspectable
    public var enableMultipleStrokes: Bool = true
    @IBInspectable
    public var timeoutBetweenStrokes: Double = 0.8
    
    private(set) public var predictedDigit: Int?
    public var bezierPath: UIBezierPath? {
        get {
            return glyph?.bezierPath
        }
    }
    
    private var glyph: GestureGlyph? {
        didSet {
            glyph?.clientSize = view?.bounds.size ?? .zero
            glyph?.strokes = [GestureStroke]()
        }
    }
    
    private var idleTimer: Timer?
    private lazy var cartesianModel = {
        return UCD_DigitGestureModelCartesian()
    }()
    
    public override func reset() {
        super.reset()
        idleTimer?.invalidate()
        idleTimer = nil
        glyph = nil
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        resetIdleTimer()
        
        if let touch = touches.first {
            let gestureTouch = GestureTouch(location: touch.location(in: view), timestamp: Double(CFAbsoluteTimeGetCurrent()))
            let gestureStroke = GestureStroke()
            gestureStroke.touches = [gestureTouch]
            if let glyph = self.glyph {
                // add stroke to existing glyph
                glyph.strokes?.append(gestureStroke)
            } else {
                // new glyph
                glyph = GestureGlyph()
                glyph?.clientSize = view?.bounds.size ?? .zero
                glyph?.strokes = [gestureStroke]
            }
        }
        
        if state == .possible {
            state = .began
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        resetIdleTimer()
        
        if let touch = touches.first {
            if let gestureStroke = glyph?.strokes?.last {
                let gestureTouch = GestureTouch(location: touch.location(in: view), timestamp: Double(CFAbsoluteTimeGetCurrent()))
                gestureStroke.touches?.append(gestureTouch)
            }
        }
        recognize()
        state = .changed
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        if enableMultipleStrokes {
            idleTimer = Timer.scheduledTimer(withTimeInterval: timeoutBetweenStrokes, repeats: false) { (timer) in
                self.recognize()
                self.state = .ended
            }
        } else {
            recognize()
            state = .ended
        }
    }
    
    private func recognize() {
        if let cartesianData = glyph?.cartesianData {
            guard cartesianData.count > 0 else {
                predictedDigit = nil
                return
            }
            guard let multiArrayCartesian = try? MLMultiArray(shape: [1, 131, 2], dataType: .double) else { return }
            
            var doubleArray = multiArrayCartesian.dataPointer.bindMemory(to: Double.self, capacity:multiArrayCartesian.count)
            for i in 0..<multiArrayCartesian.count { doubleArray.advanced(by: i).pointee = 0.0 }
            for (index, item) in cartesianData.enumerated() {
                if index < 131 {
                    doubleArray.pointee = item.x
                    doubleArray = doubleArray.advanced(by: 1)
                    doubleArray.pointee = item.y
                    doubleArray = doubleArray.advanced(by: 1)
                }
            }
            
            guard let cartesianModel_prediction = try? cartesianModel.prediction(features_input: multiArrayCartesian) else {
                fatalError("Unexpected runtime error: model.prediction")
            }
            
            predictedDigit = Int(cartesianModel_prediction.predicted_digit)
        }
    }
    
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        predictedDigit = nil
        state = .cancelled
    }
    
    private func resetIdleTimer() {
        if let timer = idleTimer {
            if timer.fireDate.timeIntervalSinceNow < timeoutBetweenStrokes {
                timer.fireDate = Date(timeIntervalSinceNow: timeoutBetweenStrokes)
            }
        }
    }
    
}




fileprivate struct GestureTouch {
    var location: CGPoint
    var timestamp: Double
}

fileprivate class GestureStroke {
    var touches: [GestureTouch]?
    var duration: Double {
        get {
            let start = touches?.first?.timestamp ?? 0.0
            return start - (touches!.last?.timestamp ?? 0.0)
        }
    }
}

fileprivate class GestureGlyph {
    var clientSize = CGSize.zero
    var strokes: [GestureStroke]?
    
    static func InterpolateWithLinear(interpolationPoints: [CGPoint]) -> UIBezierPath? {
        guard interpolationPoints.count > 1 else { return nil }
        let path =  UIBezierPath()
        path.move(to: interpolationPoints[0])
        for point in interpolationPoints[1..<interpolationPoints.count] {
            path.addLine(to: point)
        }
        return path
    }
    
    public var bezierPath: UIBezierPath? {
        get {
            if let strokes = self.strokes {
                let path = UIBezierPath()
                for stroke in strokes {
                    let points = stroke.touches!.map { $0.location }
                    if let strokePath = (type(of: self)).InterpolateWithLinear(interpolationPoints: points) {
                        path.append(strokePath)
                    }
                }
                return path
            }
            else {
                return nil
            }
        }
    }
    
    public var cartesianData: [(x: Double, y: Double)]? {
        get {
            if let strokes = self.strokes {
                var cartesianData = [(Double, Double)]()
                for stroke in strokes {
                    let touches = stroke.touches!
                    if var prevTouch = touches.first {
                        for touch in touches {
                            if prevTouch.location == touch.location {
                                continue
                            }
                            cartesianData.append((Double(touch.location.x), Double(touch.location.y)))
                            prevTouch = touch
                        }
                    }
                }
                return cartesianData
            } else {
                return nil
            }
        }
    }
}

