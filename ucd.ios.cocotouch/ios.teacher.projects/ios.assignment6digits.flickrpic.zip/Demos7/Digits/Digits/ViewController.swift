// Copyright © 2017 UCD. All rights reserved.

/* CITE: http://arxiv.org/abs/1709.06871
 
 Philip J. Corr, Guenole C. Silvestre, Chris J. Bleakley
 Open Source Dataset and Deep Learning Models for Online Digit Gesture Recognition on Touchscreens
 Irish Machine Vision and Image Processing Conference (IMVIP) 2017
 Maynooth, Ireland, 30 August-1 September 2017
 
 @inproceedings{1709.06871,
     Author     = {Philip J. Corr and Guenole C. Silvestre and Chris J. Bleakley},
     Title      = {Open Source Dataset and Deep Learning Models for Online Digit Gesture Recognition on Touchscreens},
     Booktitle  = {Irish Machine Vision and Image Processing Conference ({IMVIP}) 2017, Maynooth, Ireland, August 30--September 1, 2017},
     Year       = {2017},
     eprint     = {arXiv:1709.06871},
     url        = {http://arxiv.org/abs/1709.06871}
 }
 */

import UIKit

class BezierPathView: UIView {
    
    var bezierPath: UIBezierPath? {
        didSet {
            setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        if let path = bezierPath {
            UIColor.black.setStroke()
            path.lineCapStyle = .round
            path.lineWidth = 8 * CGFloat(bounds.size.width / 375.0)
            path.stroke()
        }
    }
}

class ViewController: UIViewController {
    
    @IBOutlet weak var inferenceLabel: UILabel!
    @IBOutlet weak var bezierView: BezierPathView!
    
    @IBAction func handleDigitGestureRecognizer(_ sender: UCD_DigitGestureRecognizer) {
        if let digit = sender.predictedDigit {
            inferenceLabel.text = "\(digit)"
        }
        bezierView.bezierPath = sender.bezierPath
        if sender.state == .recognized {
            DispatchQueue.main.async {
                self.inferenceLabel.text = "Inference Result"
                self.bezierView.bezierPath = nil
            }
        }
    }
}
