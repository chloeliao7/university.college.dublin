//
//  Photographer.swift
//  FlickrPeek
//
//  Created by COMP47390 on 26/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit
import CoreData

class Photographer: NSManagedObject {
    class func photographerWithDict(_ flickrInfo: [String: AnyObject], inContext context: NSManagedObjectContext) throws -> Photographer {
        // to be completed
        let name = flickrInfo[FlickrFetcher.FlickrAPI.FLICKR_PHOTO_OWNER] as! String
        let request: NSFetchRequest<Photographer> = Photographer.fetchRequest()
        request.predicate = NSPredicate(format: "name = %@", name)
        do {
            let matches = try context.fetch(request)
            if matches.count > 0 {
                assert(matches.count == 1, "Photographer.photographerWithDict -- database inconsistency")
                return matches[0]
            }
        } catch { throw error }
        let photographer = Photographer(context: context)
        photographer.name = name
        return photographer
    }
}
