//
//  Photo.swift
//  FlickrPeek
//
//  Created by COMP47390 on 26/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit
import CoreData

class Photo: NSManagedObject {
    
    class func photoWithDict(_ flickrInfo: [String: AnyObject], inContext context: NSManagedObjectContext) throws -> Photo {
        let uniqueID = flickrInfo[FlickrFetcher.FlickrAPI.FLICKR_PHOTO_ID] as! String
        let request: NSFetchRequest<Photo> = Photo.fetchRequest()
        request.predicate = NSPredicate(format: "uniqueID = %@", uniqueID)
        do {
            let matches = try context.fetch(request)
            if matches.count > 0 {
                assert(matches.count == 1, "Photo.photoWithDict -- database inconsistency")
                return matches[0]
            }
        } catch { throw error }
        
        let photo = Photo(context: context)
        // set photo properties from Flickr dict
        photo.title = flickrInfo[FlickrFetcher.FlickrAPI.FLICKR_PHOTO_TITLE] as? String
        photo.subtitle = flickrInfo[FlickrFetcher.FlickrAPI.FLICKR_PHOTO_DESCRIPTION] as? String
        photo.uniqueID = uniqueID
        photo.imageURL = FlickrFetcher.url(forPhoto: flickrInfo, format: FlickrFetcher.FlickrPhotoFormat.flickrPhotoFormatMedium640)?.absoluteString
        photo.thumbnailURL = FlickrFetcher.url(forPhoto: flickrInfo, format: FlickrFetcher.FlickrPhotoFormat.flickrPhotoFormatSquare)?.absoluteString
        photo.whoTook = try? Photographer.photographerWithDict(flickrInfo, inContext: context)
        
        print("is main thread? \(Thread.isMainThread)")
        if let thumbnailURL = photo.thumbnailURL {
            FlickrFetcher.startFlickrFetch(URL(string: thumbnailURL)!) { (data) in
                // add thumnail data to database
                context.perform {
                    print("is main thread? \(Thread.isMainThread)")
                    if let fetchData = data {
                        print("store thumbnail image data in photo.thumbnail")
                        if let image = UIImage(data: fetchData)?.sizeTo(CGSize(width:64, height: 64)) {
                            photo.thumbnail = image.pngData()
                        }
                    }
                }
            }
        }
        return photo
    }
}

private extension UIImage {
    func sizeTo(_ size: CGSize) -> UIImage {
        guard self.size != size else { return self }
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        self.draw(in: CGRect(origin: .zero, size: size))
        let image = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return image
    }
}
