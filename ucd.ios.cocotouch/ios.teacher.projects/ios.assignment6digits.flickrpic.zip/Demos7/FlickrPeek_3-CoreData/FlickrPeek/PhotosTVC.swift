//
//  PhotosTVC.swift
//  FlickrPeek
//
//  Created by COMP47390 on 26/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit
import CoreData

class PhotosTVC: CoreDataTVC {
    private var thumbnailCache = [String: Data]()
    public var photographer: Photographer? {
        didSet {
            self.title = photographer?.name
        }
    }
    private var fetchedResultsController: NSFetchedResultsController<Photo>?

    private func updateUI() {
        if let context = photographer?.managedObjectContext {
            let request: NSFetchRequest<Photo> = Photo.fetchRequest()
            request.sortDescriptors = [NSSortDescriptor(key: "title", ascending: true, selector: #selector(NSString.localizedCaseInsensitiveCompare(_:)))]
            request.predicate = NSPredicate(format: "whoTook.name = %@", (photographer?.name)!)
            fetchedResultsController =  NSFetchedResultsController<Photo>(fetchRequest: request, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            try? fetchedResultsController?.performFetch()
            tableView.reloadData()
        }
    }
    
    // MARK:- VC Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources than can be recreated
        thumbnailCache.removeAll()
    }
    
    // MARK:- Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let indexPath = tableView.indexPath(for: sender as! UITableViewCell), let photo = fetchedResultsController?.object(at: indexPath)
        {
            let imageVC = segue.destination as! ImageVC
            imageVC.imageURL = URL(string: photo.imageURL!)
            imageVC.title = photo.title
        }
    }
}

extension PhotosTVC {
    // MARK:- TableView DataSource
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return fetchedResultsController?.sections?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = fetchedResultsController?.sections, sections.count > 0 {
            return sections[section].numberOfObjects
        } else  {
            return 0
        }
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if let sections = fetchedResultsController?.sections, sections.count > 0 {
            return sections[section].name
        } else {
            return nil
        }
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return fetchedResultsController?.sectionIndexTitles
    }
    override func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        return fetchedResultsController?.section(forSectionIndexTitle: title, at: index) ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dequeuedCell = tableView.dequeueReusableCell(withIdentifier: "FlickrCell", for: indexPath)
        // Configure cell
        let photo = fetchedResultsController?.object(at: indexPath)
        dequeuedCell.detailTextLabel?.text = photo?.subtitle
        dequeuedCell.textLabel?.text = photo?.title
        if let cacheID = photo?.uniqueID {
            if let cacheData = thumbnailCache[cacheID] {
                print("reading thumbnail from cache at row: \(indexPath.row)")
                dequeuedCell.imageView?.image = UIImage(data: cacheData)
                dequeuedCell.imageView?.contentMode = .scaleAspectFill
            } else {
                dequeuedCell.imageView?.image = #imageLiteral(resourceName: "ucd")
                if let url = URL(string: (photo?.thumbnailURL)!) {
                    FlickrFetcher.startFlickrFetch(url) { [unowned self] (data) in
                        Thread.sleep(forTimeInterval: 3)
                        print("fetching thumbnail for row: \(indexPath.row)")
                        if let fetchData = data {
                            print("caching thumbnail for row: \(indexPath.row)")
                            self.thumbnailCache[cacheID] = fetchData
                            DispatchQueue.main.async {
                                self.tableView.reloadRows(at: [indexPath], with: .left)
                            }
                        }
                    }
                    
                }
            }
        }
        return dequeuedCell
    }
    
}

