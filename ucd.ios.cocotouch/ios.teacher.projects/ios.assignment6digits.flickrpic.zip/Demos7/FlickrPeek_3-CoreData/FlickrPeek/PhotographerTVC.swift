//
//  PhotographerTVC.swift
//  FlickrPeek
//
//  Created by COMP47390 on 06/03/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit
import CoreData

class PhotographerTVC: CoreDataTVC {
    private var fetchedResultsController: NSFetchedResultsController<Photographer>?
    
    let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    
    private func updateCoreData(with photos: [[String: AnyObject]]) {
        print("updating coredata")
        
        container?.performBackgroundTask { [weak self] context in
            for photo in photos {
                _ = try? Photo.photoWithDict(photo, inContext: context)
            }
            try? context.save()
            print("coredata update completed")
            self?.printCoreDataStats()
            DispatchQueue.main.async {
                self?.updateUI()
            }
            
        }
    }
    
    private func printCoreDataStats() {
        if let context = container?.viewContext {
            context.perform {
                if Thread.isMainThread { print("on main thread") }
                else { print("off main thread") }
                // bad way to count objects
                if let photoCount = (try? context.fetch(Photo.fetchRequest() as NSFetchRequest<Photo>))?.count {
                    print("\(photoCount) photos")
                }
                // better way to count objects
                if let photographerCount = try? context.count(for: Photographer.fetchRequest()) {
                    print("\(photographerCount) photographers")
                }
            }
        }
    }
    
    private func updateUI() {
        if let context = container?.viewContext {
            let request: NSFetchRequest<Photographer> = Photographer.fetchRequest()
            request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.localizedCaseInsensitiveCompare(_:)))]
            fetchedResultsController =  NSFetchedResultsController<Photographer>(fetchRequest: request, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            try? fetchedResultsController?.performFetch()
            tableView.reloadData()
        }
    }
    
    private func fetchImages() {
        if let fetchUrl = FlickrFetcher.urlForRecentGeoreferencedPhotos() {
            FlickrFetcher.startFlickrFetch(fetchUrl, completion: { (data) in
                if let fetchData = data {
                    do {
                        let plistDict = try JSONSerialization.jsonObject(with: fetchData, options: []) as AnyObject
                        if let photos = plistDict.value(forKeyPath: FlickrFetcher.FlickrAPI.FLICKR_PHOTOS) as? [[String: AnyObject]] {
                            self.updateCoreData(with: photos)
                        }
                    } catch { print("fetch failed: \((error as NSError).localizedDescription)") }
                }
            })
        }
    }    
    
    // MARK:- VC Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        fetchImages()
        title = "Flickr Recents"
    }
    
    // MARK:- Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let indexPath = tableView.indexPath(for: sender as! UITableViewCell), let photographer = fetchedResultsController?.object(at: indexPath), let photosTVC = segue.destination as? PhotosTVC {
            photosTVC.photographer = photographer
        }
    }
}


extension PhotographerTVC {
    // MARK:- TableView DataSource
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return fetchedResultsController?.sections?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = fetchedResultsController?.sections, sections.count > 0 {
            return sections[section].numberOfObjects
        } else  {
            return 0
        }
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if let sections = fetchedResultsController?.sections, sections.count > 0 {
            return sections[section].name
        } else {
            return nil
        }
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return fetchedResultsController?.sectionIndexTitles
    }
    override func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        return fetchedResultsController?.section(forSectionIndexTitle: title, at: index) ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dequeuedCell = tableView.dequeueReusableCell(withIdentifier: "PhotographerCell", for: indexPath)
        // Configure cell
        if let photographer = fetchedResultsController?.object(at: indexPath) {
            dequeuedCell.textLabel?.text = photographer.name
            dequeuedCell.detailTextLabel?.text = "\(photographer.photos!.count)"
        }
        return dequeuedCell
    }
}
