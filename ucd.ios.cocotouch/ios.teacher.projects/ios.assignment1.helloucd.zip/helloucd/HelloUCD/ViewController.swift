//
//  ViewController.swift
//  HelloUCD
//
//  Created by Greg Cousin on 1/22/19.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }
}
