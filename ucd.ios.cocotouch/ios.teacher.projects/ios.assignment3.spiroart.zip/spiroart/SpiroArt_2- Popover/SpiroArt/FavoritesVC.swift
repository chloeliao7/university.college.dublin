//
//  FavoritesVC.swift
//  SpiroArt
//
//  Created by COMP47390 on 13/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class FavoritesVC: UIViewController {
    var text: String = "" {
        didSet { favoritesTextView?.text = text }
    }
    
    @IBOutlet weak var favoritesTextView: UITextView! {
        didSet { favoritesTextView.text = text }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override var preferredContentSize: CGSize {
        get {
            if favoritesTextView.text != nil && presentingViewController != nil {
                return favoritesTextView.sizeThatFits(presentingViewController!.view.bounds.size)
            } else {
                return super.preferredContentSize
            }
        }
        set {
            super.preferredContentSize = newValue
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
