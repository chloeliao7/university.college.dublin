//
//  LoggedSpirographVC.swift
//  SpiroArt
//
//  Created by COMP47390 on 13/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import Foundation
import UIKit

class LoggedSpirographVC: SpirographVC, UIPopoverPresentationControllerDelegate {
    
    private var defaults = UserDefaults.standard
    
    var spirographLog: [SpirographModel] {
        set {
            let serialisedLog = newValue.map { "\($0)" }
            defaults.set(serialisedLog, forKey: Identifiers.defaultKey)
            defaults.synchronize()
        }
        get {
            let serialisedLog = defaults.object(forKey: Identifiers.defaultKey) as? [String] ?? []
            return serialisedLog.map { SpirographModel(fromText: $0) }
        }
    }
    
    override var spirographModel: SpirographModel {
        didSet {
            // should check that spirographModel is not in spirographLog before re-enabling button
            addButton.isEnabled = true
        }
    }
    
    private struct Identifiers {
        static let showFavoritesPopover = "showFavoritesPopover"
        static let defaultKey = "SpiroArt.Favorites"
    }
    
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    @IBAction func addSpirographToLog(_ sender: UIBarButtonItem) {
        spirographLog.append(spirographModel)
        addButton.isEnabled = false
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier! {
        case Identifiers.showFavoritesPopover:
            if let favoritesVC = segue.destination as? FavoritesVC {
                favoritesVC.text = "\(spirographLog)"
                if let ppc = favoritesVC.popoverPresentationController {
                    ppc.delegate =  self
                }
            }
        default:
            break
        }
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
}


extension SpirographModel {
    convenience init(fromText text: String) {
        self.init()
        let token = text.components(separatedBy: CharacterSet(charactersIn: " ="))
        print(token)
        self.M = Int(token[1])!
        self.N = Int(token[3])!
        self.F = Float(token[5])!
    }
}
