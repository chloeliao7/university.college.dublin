//
//  SpirographView.swift
//  Spirograph
//
//  Created by Me on 26/01/2018.
//  Copyright © 2018 UCD. All rights reserved.
//

import UIKit

protocol SpirographViewDataSource: class {
    func vertices(forSpirographView spirographView: SpirographView) -> [CGPoint]?
    var vertexRadius: CGFloat { get }
}

@IBDesignable class SpirographView: UIView {
    @IBInspectable var fillColor: UIColor = UIColor.clear
    @IBInspectable var strokeColor: UIColor = UIColor.black
    @IBInspectable var lineWidth: CGFloat = 0.5
    var spirographScale: CGFloat = 0.88 { didSet { setNeedsDisplay() } }
    var spirographCenter: CGPoint { return convert(center, from: superview) }
    var spirographRadius: CGFloat { return min(bounds.size.width, bounds.size.height) / 2 * spirographScale }
    weak var dataSource: SpirographViewDataSource?

    @objc func scaleView(gesture: UIPinchGestureRecognizer) {
        if gesture.state == .changed {
            spirographScale *= gesture.scale
            gesture.scale = 1.0
        }
    }
    
    override func draw(_ rect: CGRect) {
        // draw circle
        fillColor.setFill()
        var path = UIBezierPath(arcCenter: spirographCenter, radius: spirographRadius, startAngle: 0, endAngle: 2 * CGFloat.pi, clockwise: true)
        UIColor(white: 0.5, alpha: 1).setStroke()
        path.lineWidth = CGFloat(lineWidth)
        path.stroke()
        
        // draw spirograph vertices
        if let vertices = dataSource?.vertices(forSpirographView: self) {
            path = UIBezierPath()
            for vertex in vertices {
                path.append(UIBezierPath(arcCenter: vertex, radius: dataSource!.vertexRadius, startAngle: 0, endAngle: 2 * CGFloat.pi, clockwise: true))
            }
            fillColor.setFill()
            path.fill()
            
            // join spirograph vertices
            path = UIBezierPath()
            path.move(to: vertices[0])
            for vertex in vertices[1..<vertices.count] {
                path.addLine(to: vertex)
            }
            strokeColor.setStroke()
            path.lineWidth = CGFloat(lineWidth)
            path.stroke()
        }
    }
    
}

extension Int {
    func gcd(_ number: Int) -> Int {
        var a = abs(self)
        var b = abs(number)
        if b > a { (a, b) = (b, a) }
        while b > 0 {
            (a, b) = (b, a % b)
        }
        return a
    }
}

