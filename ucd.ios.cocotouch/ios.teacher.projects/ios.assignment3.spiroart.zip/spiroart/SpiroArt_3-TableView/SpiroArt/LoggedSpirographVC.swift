//
//  LoggedSpirographVC.swift
//  SpiroArt
//
//  Created by Me on 30/01/2018.
//  Copyright © 2018 UCD. All rights reserved.
//

import UIKit

class LoggedSpirographVC: SpirographVC, UIPopoverPresentationControllerDelegate {
    @IBOutlet weak var addButton: UIBarButtonItem!
    private let defaults = UserDefaults.standard
    var spirographLog: [SpirographModel] {
        set {
            let serializedLog = newValue.map {"\($0)" }
            defaults.set(serializedLog, forKey: Identifiers.defaultsKey)
            defaults.synchronize()
        }
        get {
            let serializedLog = defaults.object(forKey: Identifiers.defaultsKey) as? [String] ?? []
            return serializedLog.map { SpirographModel(fromText: $0) }
        }
    }
    override var spirographModel: SpirographModel {
        didSet { addButton.isEnabled = true }
    }

    @IBAction func addSpirographToFavorites(_ sender: UIBarButtonItem) {
        spirographLog.append(spirographModel)
        addButton.isEnabled = false
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return .none
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private struct Identifiers {
        static let showFavoritesPopover = "showFavoritesPopover"
        static let defaultsKey = "SpiroArt.Favorites"
    }

    // MARK: - Navigation
    @IBAction func unwindFromFavoritesTVC(_ unwindSegue: UIStoryboardSegue) {
        print("\(spirographModel)")
    }
 
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier! {
        case Identifiers.showFavoritesPopover:
            if let favoritesTVC = segue.destination as? FavoritesTVC  {
                favoritesTVC.dataModel = spirographLog
                if let popover = favoritesTVC.popoverPresentationController {
                    popover.delegate = self
                }
            }
        default:
            break
        }
    }

}
