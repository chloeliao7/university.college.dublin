//
//  GalleryVC.swift
//  SpiroArt
//
//  Created by Me on 28/01/2018.
//  Copyright © 2018 UCD. All rights reserved.
//

import UIKit

class GalleryVC: UIViewController {
    
    enum StoryboardIdentifiers: String {
        case artwork1 = "showArtwork1"
        case artwork2 = "showArtwork2"
        case artwork3 = "showArtwork3"
        case custom = "showCustom"
        
        init?(_ segue: UIStoryboardSegue) {
            self.init(rawValue: segue.identifier!)
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var destinationVC = segue.destination
        if let navigationVC = destinationVC as? UINavigationController {
            destinationVC = navigationVC.visibleViewController!
        }
        switch StoryboardIdentifiers(segue)! {
        case .artwork1:
            if let spirographVC = destinationVC as? SpirographVC {
                spirographVC.spirographModel = SpirographModel(M: 144, N: 64, F: 0.9)
            }
        case .artwork2:
            if let spirographVC = destinationVC as? SpirographVC {
                spirographVC.spirographModel = SpirographModel(M: 150, N: 42, F: 0.8)
            }
        case .artwork3:
            if let spirographVC = destinationVC as? SpirographVC {
                spirographVC.spirographModel = SpirographModel(M: 105, N: 80, F: 1.0)
            }
        case .custom:
            if let spirographVC = destinationVC as? SpirographVC {
                spirographVC.spirographModel = SpirographModel(M: 144, N: 64, F: 0.9)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

