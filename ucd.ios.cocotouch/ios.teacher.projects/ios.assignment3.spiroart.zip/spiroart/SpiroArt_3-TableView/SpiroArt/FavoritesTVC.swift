//
//  FavoritesTVC.swift
//  SpiroArt
//
//  Created by Me on 30/01/2018.
//  Copyright © 2018 UCD. All rights reserved.
//

import UIKit

class SpirographCell: UITableViewCell, SpirographViewDataSource {
    @IBOutlet weak var spirographDetails: UILabel!
    @IBOutlet weak var spirographView: SpirographView!
    var spirographModel: SpirographModel? {
        didSet {
            spirographDetails?.text = "\(spirographModel!)"
            spirographView?.dataSource = self
            spirographView?.setNeedsDisplay()
        }
    }
    
    // Conform to SpirographViewDataSource protocol
    func vertices(forSpirographView sender: SpirographView) -> [CGPoint]? {
        if let vertices = spirographModel?.vertices(atCenter: sender.spirographCenter, forRadius: sender.spirographRadius) {
            guard vertices.count > 1 else {
                return nil
            }
            return vertices
        } else {
            return nil
        }
    }
    
    var vertexRadius: CGFloat = 0.0
}

class FavoritesTVC: UITableViewController {
    var dataModel = [SpirographModel]() {
        didSet { tableView.reloadData() }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModel.count
    }
    
    private struct Identifiers {
        static let spirographCell: String = "Spirograph Cell"
        static let unwindSegue: String = "Unwind LoggedSpirographVC"
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let spirograph = dataModel[indexPath.row]
        let dequeued: AnyObject = tableView.dequeueReusableCell(withIdentifier: Identifiers.spirographCell, for: indexPath)
        let cell = dequeued as! SpirographCell
        cell.spirographModel = spirograph
        return cell

    }

    override var preferredContentSize: CGSize {
        get {
            if tableView != nil  && presentingViewController != nil {
                return tableView.sizeThatFits(presentingViewController!.view.bounds.size)
            } else {
                return super.preferredContentSize
            }
        }
        set {
            super.preferredContentSize = newValue
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier! {
        case Identifiers.unwindSegue:
            let destinationVC = segue.destination as! LoggedSpirographVC
            let cell = sender as! SpirographCell
            destinationVC.spirographModel = cell.spirographModel!
            destinationVC.addButton.isEnabled = false
        default:
            break
        }
    }
    
}
