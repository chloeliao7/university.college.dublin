//
//  ViewController.swift
//  Spirograph
//
//  Created by Me on 26/01/2018.
//  Copyright © 2018 UCD. All rights reserved.
//

import UIKit

class SpirographVC: UIViewController, SpirographViewDataSource {
    @IBOutlet weak var spirographView: SpirographView! {
        didSet {
            spirographView.dataSource = self
            spirographView.addGestureRecognizer(UIPinchGestureRecognizer(target: spirographView, action: #selector(spirographView.scaleView(gesture:))))
        }
    }
    var spirographModel = SpirographModel() { didSet { updateUI() } }
    private var completion: Float = 1.0 {
        didSet {
            completion = min(max(completion, 0.0), 1.0)
            updateUI()
        }
    }

    private func updateUI()
    {
        title = "\(spirographModel)"
        spirographView?.setNeedsDisplay()
    }
    
    // MARK: - SpirographViewDataSource
    func vertices(forSpirographView spirographView: SpirographView) -> [CGPoint]? {
        var vertices = spirographModel.vertices(atCenter: spirographView.spirographCenter, forRadius: spirographView.spirographRadius)
        
        guard vertices.count > 1 else { return nil }
        let count  = max(Int(Float(vertices.count) * completion), 1)
        vertices = Array(vertices[0..<count])
        if completion == 1.0 { vertices.append(vertices[0]) }
        return vertices
    }
    
    var vertexRadius: CGFloat { return 2.0 }
    
    // MARK: - VC Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Target/Actions
    @IBAction func setStator(_ sender: UISlider) {
        spirographModel = SpirographModel(M: Int(sender.value), N: spirographModel.N, F: spirographModel.F)
    }

    @IBAction func setRotor(_ sender: UISlider) {
        spirographModel = SpirographModel(M: spirographModel.M, N: Int(sender.value), F: spirographModel.F)
    }
    
    @IBAction func setPenLocation(_ sender: UISlider) {
        spirographModel = SpirographModel(M: spirographModel.M, N: spirographModel.N, F: sender.value)
    }
    
    @IBAction func drawCompletion(_ sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .ended: fallthrough
        case .changed:
            let translation = sender.translation(in: spirographView)
            completion += Float(translation.x / spirographView.frame.size.width * 2.0)
            sender.setTranslation(CGPoint.zero, in: spirographView)
        default:
            break
        }
    }
}
