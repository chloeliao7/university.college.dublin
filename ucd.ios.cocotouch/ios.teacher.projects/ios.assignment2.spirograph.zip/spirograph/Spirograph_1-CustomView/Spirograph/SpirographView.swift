//
//  SpirographView.swift
//  Spirograph
//
//  Created by COMP47390 on 05/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

@IBDesignable class SpirographView: UIView {
    @IBInspectable private var strokeColor: UIColor = UIColor.green
    @IBInspectable private var fillColor: UIColor = UIColor.blue
    @IBInspectable private var lineWidth: CGFloat = 1.5
    var spirographCenter: CGPoint { return convert(center, from: superview) }
    var spirographRadius: CGFloat { return min(bounds.size.width, bounds.size.height) / 2 * spirographScale
    }
    var spirographScale: CGFloat = 0.88
    
    @IBInspectable var M: Int = 38
    @IBInspectable var N: Int = 12
    @IBInspectable var F: Float = 0.8
    
    private struct Constants {
        static let rotorInterpolationPoints = 38
        static let vertexRadius: CGFloat = 2.5
    }
    
    private func spirographVertices(atCenter center: CGPoint, forRadius radius: CGFloat) -> [CGPoint] {
        var vertices = [CGPoint]()
        let GCD = M.gcd(N)
        let numberOfVertices = CGFloat(Constants.rotorInterpolationPoints * N / GCD)
        let twoNPiGCD = CGFloat(N) * 2 * CGFloat.pi / CGFloat(GCD)
        let NoverM = CGFloat(N) / CGFloat(M)
        let MoverN = 1 / NoverM
        
        for t in stride(from: 0.0, to: twoNPiGCD, by: twoNPiGCD / numberOfVertices) {
            var point = center
            point.x += radius * (1 - NoverM) * cos(t)
            point.x += radius * CGFloat(F) * NoverM * cos((MoverN - 1) * t)
            point.y += radius * (1 - NoverM) * sin(t)
            point.y -= radius * CGFloat(F) * NoverM * sin((MoverN - 1) * t)
            vertices.append(point)
        }
        return vertices
    }
    

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        
        // draw circle
        var path = UIBezierPath(arcCenter: spirographCenter, radius: spirographRadius, startAngle: 0, endAngle: CGFloat.pi * 2, clockwise: true)
        path.lineWidth = lineWidth
        UIColor.gray.withAlphaComponent(0.5).setStroke()
        path.stroke()
        
        // draw spirograph vertices
        let vertices = spirographVertices(atCenter: spirographCenter, forRadius: spirographRadius)
        path = UIBezierPath()
        for vertex in vertices {
            path.append(UIBezierPath(arcCenter: vertex, radius: Constants.vertexRadius, startAngle: 0, endAngle: 2 * CGFloat.pi, clockwise: true))
        }
        fillColor.setFill()
        path.fill()
        
        // join spirograph vertices
        path = UIBezierPath()
        path.move(to: vertices[0])
        for vertex in vertices[1..<vertices.count] {
            path.addLine(to: vertex)
        }
        path.close()
        strokeColor.setStroke()
        path.lineWidth = lineWidth
        path.stroke()
    }
    

}

extension  Int {
    func gcd(_ number: Int) -> Int {
        var a = abs(self)
        var b = abs(number)
        if b > a { (a, b) = (b, a) }
        while b > 0 {
            (a, b) = (b, a % b)
        }
        return a
    }
}
