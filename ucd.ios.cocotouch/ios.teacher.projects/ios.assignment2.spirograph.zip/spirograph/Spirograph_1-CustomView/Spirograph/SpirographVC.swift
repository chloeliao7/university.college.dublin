//
//  SpirographVC.swift
//  Spirograph
//
//  Created by COMP47390 on 05/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class SpirographVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

