//
//  SpirographVC.swift
//  Spirograph
//
//  Created by COMP47390 on 05/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class SpirographVC: UIViewController, SpirographViewDataSource {
    
    private var completion: Float = 1.0 {
        didSet {
            completion = min(max(completion, 0.0), 1.0)
            updateUI()
        }
    }
    
    func vertices(forSpirographView spirographView: SpirographView) -> [CGPoint]? {
        var vertices = spirographModel.spirographVertices(atCenter: spirographView.spirographCenter, forRadius: spirographView.spirographRadius)
        let count = max(Int(Float(vertices.count) * completion), 1)
        vertices = Array(vertices[0..<count])
        if completion == 1.0 {
            vertices.append(vertices[0])
        }
        guard vertices.count > 1 else {
            return nil
        }
        return vertices
    }
    
    @IBAction func scaleView(_ gesture: UIPinchGestureRecognizer) {
        if gesture.state == .changed {
            print("\(gesture.scale)")
            gesture.scale = 1.0
        }
    }
    
    var vertexRadius: CGFloat {
        return SpirographModel.Constants.vertexRadius
    }
    
    @IBAction func setStator(_ sender: UISlider) {
        spirographModel = SpirographModel(M: Int(sender.value), N: spirographModel.N, F: spirographModel.F)
    }
    
    @IBAction func setRotor(_ sender: UISlider) {
        spirographModel = SpirographModel(M: spirographModel.M, N: Int(sender.value),F: spirographModel.F)
    }
    
    @IBAction func setPenLocation(_ sender: UISlider) {
        spirographModel = SpirographModel(M: spirographModel.M, N: spirographModel.N, F: Float(sender.value))

    }
    
    @IBAction func drawCompletion(_ sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .ended: fallthrough
        case .changed:
            let translation = sender.translation(in: spirographView)
            completion += Float(translation.x / spirographView.frame.size.width * 2)
            sender.setTranslation(CGPoint.zero, in: spirographView)
        default:
            break
        }
    }
    
    @IBOutlet var spirographView: SpirographView! {
        didSet {
            spirographView.dataSource = self
            spirographView.addGestureRecognizer(UIPinchGestureRecognizer(target: spirographView, action: #selector(spirographView.scaleView(gesture:))))
        }
    }
    
    
    var spirographModel = SpirographModel() {
        didSet{
            updateUI()
        }
    }
    
    private func updateUI() {
        spirographView.setNeedsDisplay()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

