//
//  SpirographView.swift
//  Spirograph
//
//  Created by COMP47390 on 05/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

protocol SpirographViewDataSource: class {
    func vertices(forSpirographView spirographView: SpirographView) -> [CGPoint]?
    var vertexRadius: CGFloat { get }
}

@IBDesignable class SpirographView: UIView {
    @IBInspectable private var strokeColor: UIColor = UIColor.green
    @IBInspectable private var fillColor: UIColor = UIColor.blue
    @IBInspectable private var lineWidth: CGFloat = 1.5

    weak var dataSource: SpirographViewDataSource?
    
    var spirographScale: CGFloat = 0.88
    var spirographCenter: CGPoint { return convert(center, from: superview) }
    var spirographRadius: CGFloat { return min(bounds.size.width, bounds.size.height) / 2 * spirographScale }
    
    override func draw(_ rect: CGRect) {
        // draw circle
        var path = UIBezierPath(arcCenter: spirographCenter, radius: spirographRadius, startAngle: 0, endAngle: CGFloat.pi * 2, clockwise: true)
        path.lineWidth = lineWidth
        UIColor.gray.withAlphaComponent(0.5).setStroke()
        path.stroke()
        
        // draw spirograph
        if let vertices = dataSource?.vertices(forSpirographView: self),
            // draw vertices
            let radius = dataSource?.vertexRadius {
            path = UIBezierPath()
            for vertex in vertices {
                path.append(UIBezierPath(arcCenter: vertex, radius: radius, startAngle: 0, endAngle: 2 * CGFloat.pi, clockwise: true))
            }
            fillColor.setFill()
            path.fill()
            
            // join vertices
            path = UIBezierPath()
            path.move(to: vertices[0])
            for vertex in vertices[1..<vertices.count] {
                path.addLine(to: vertex)
            }
            path.close()
            strokeColor.setStroke()
            path.lineWidth = lineWidth
            path.stroke()
        }
    }
}

extension  Int {
    func gcd(_ number: Int) -> Int {
        var a = abs(self)
        var b = abs(number)
        if b > a { (a, b) = (b, a) }
        while b > 0 {
            (a, b) = (b, a % b)
        }
        return a
    }
}
