//
//  SpirographVC.swift
//  Spirograph
//
//  Created by COMP47390 on 05/02/2019.
//  Copyright © 2019 COMP47390. All rights reserved.
//

import UIKit

class SpirographVC: UIViewController, SpirographViewDataSource {
    
    func vertices(forSpirographView spirographView: SpirographView) -> [CGPoint]? {
        let vertices = spirographModel.spirographVertices(atCenter: spirographView.spirographCenter, forRadius: spirographView.spirographRadius)
        guard vertices.count > 1 else {
            return nil
        }
        return vertices
    }
    
    @IBAction func scaleView(_ gesture: UIPinchGestureRecognizer) {
        if gesture.state == .changed {
            print("\(gesture.scale)")
            gesture.scale = 1.0
        }
    }
    
    var vertexRadius: CGFloat {
        return SpirographModel.Constants.vertexRadius
    }
    
    @IBAction func setStator(_ sender: UISlider) {
        spirographModel = SpirographModel(M: Int(sender.value), N: spirographModel.N, F: spirographModel.F)
    }
    
    @IBAction func setRotor(_ sender: UISlider) {
        spirographModel = SpirographModel(M: spirographModel.M, N: Int(sender.value),F: spirographModel.F)
    }
    
    @IBAction func setPenLocation(_ sender: UISlider) {
        spirographModel = SpirographModel(M: spirographModel.M, N: spirographModel.N, F: Float(sender.value))

    }
    @IBOutlet var spirographView: SpirographView! {
        didSet {
            spirographView.dataSource = self
        }
    }
    
    
    var spirographModel = SpirographModel() {
        didSet{
            updateUI()
        }
    }
    
    private func updateUI() {
        spirographView.setNeedsDisplay()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

