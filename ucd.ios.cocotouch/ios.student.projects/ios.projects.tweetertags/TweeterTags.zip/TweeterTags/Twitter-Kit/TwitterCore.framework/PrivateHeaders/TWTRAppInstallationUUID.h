//
//  TWTRAppInstallationUUID.h
//  TwitterKit
//
//  Created by Joey Carmello on 3/27/15.
//  Copyright (c) 2015 Twitter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TWTRAppInstallationUUID : NSObject

+ (NSString *)appInstallationUUID;

@end
