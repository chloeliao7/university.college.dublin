//
//  CoreData.swift
//  Connect4
//
//  Created by Gregoire Cousin on 22/03/2019.
//  Copyright © 2019 UCD. All rights reserved.
//

import Foundation // to delete
