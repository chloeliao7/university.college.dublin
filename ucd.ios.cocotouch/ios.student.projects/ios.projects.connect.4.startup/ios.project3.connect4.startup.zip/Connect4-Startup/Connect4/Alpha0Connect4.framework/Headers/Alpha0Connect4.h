//
//  Alpha0Connect4.h
//  Alpha0Connect4
//
//  Created by Me on 11/01/2019.
//  Copyright © 2019 UCD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Alpha0Connect4.
FOUNDATION_EXPORT double Alpha0Connect4VersionNumber;

//! Project version string for Alpha0Connect4.
FOUNDATION_EXPORT const unsigned char Alpha0Connect4VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Alpha0Connect4/PublicHeader.h>


