
# WHAT SCRIPT DOES : 
	Steps to set up venv:
	- cd into the directory
	- run: mkdir venv
	- go into the directory with: cd venv2
	- then run: python3 -m venv .
	- go back to main directory: cd ../
	- start the venv: source venv/bin/activate
	- install requirements by running: pip install -r requirements.txt
	- to run the notebook: jupyter notebook
	- this will open the browser. to go: http://localhost:8888/tree

