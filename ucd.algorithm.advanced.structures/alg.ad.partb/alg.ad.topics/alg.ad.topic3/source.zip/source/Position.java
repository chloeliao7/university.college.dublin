/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rem
 */
public interface Position {
    public Object element();
}
