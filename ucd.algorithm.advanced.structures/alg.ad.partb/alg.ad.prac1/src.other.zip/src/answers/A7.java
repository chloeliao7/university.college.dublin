import java.util.*;
import java.util.Scanner;

public class A7 {
  public static int OPCounter = 1;
  public static String OPDeclare;
  public static String OPAssign;
  public static String OPIterate;
  public static String Printall;

  public static void main(String args[]) {
    int minValueIndex = 0;
    OPAssign("int minValueIndex = 0");
    int[] A = { 5, 10, 20, 30, 40, 50 };
    int runningSum = 0;
    OPAssign("runningSum = 0");
    int n = 6;
    OPAssign("int n = 6");
    int B[] = new int[n];
    OPAssign("new int[n] to B");
    B = PrefixAverages2(runningSum, A, n);
  }

  public static int[] PrefixAverages2(int runningSum, int A[], int n) {
    double duration = 0;
    int j = 0; 
    OPAssign("First: Forloop: int j = 0");
    for (j = 0; j < n; j++) {
      long start = System.currentTimeMillis();
      increment(n);
      runningSum = runningSum + A[j];
      OPIterate("runningSum = runningSum + A[j]" + " : " + runningSum);
      A[j] = runningSum / (j + 1);
      OPIterate("A[j] = runningSum/(j+1)" + " : " + A[j]);
      long end = System.currentTimeMillis();
      duration += end - start;
    }
    OPEvaluate("LAST: j < n" + " : " + j + " < " + n);
    OPReturn("return A" + " : " + runningSum);
    duration = duration / 5;
    System.out.println("Running Time = " + duration);
    return A;
  }

  /*
  :'#######::'########::'########:'########:::::'###::::'########:'####::'#######::'##::: ##::'######::
  '##.... ##: ##.... ##: ##.....:: ##.... ##:::'## ##:::... ##..::. ##::'##.... ##: ###:: ##:'##... ##:
  ##:::: ##: ##:::: ##: ##::::::: ##:::: ##::'##:. ##::::: ##::::: ##:: ##:::: ##: ####: ##: ##:::..::
  ##:::: ##: ########:: ######::: ########::'##:::. ##:::: ##::::: ##:: ##:::: ##: ## ## ##:. ######::
  ##:::: ##: ##.....::: ##...:::: ##.. ##::: #########:::: ##::::: ##:: ##:::: ##: ##. ####::..... ##:
  ##:::: ##: ##:::::::: ##::::::: ##::. ##:: ##.... ##:::: ##::::: ##:: ##:::: ##: ##:. ###:'##::: ##:
  . #######:: ##:::::::: ########: ##:::. ##: ##:::: ##:::: ##::::'####:. #######:: ##::. ##:. ######::
  :.......:::..:::::::::........::..:::::..::..:::::..:::::..:::::....:::.......:::..::::..:::......:::
  */

  public static void OPIterate(String OPIterate) {
    System.out.println("ITERATE OPERATION #" + OPCounter++ + " ITTERATING: " + OPIterate + " ");
  }

  public static void OPAssign(String OPAssign) {
    System.out.println("ASSIGN OPERATION #" + OPCounter++ + " ASSIGNING: " + OPAssign + " ");
  }

	public static void OPEvaluate(String OPEvaluates) {
		System.out.println("EVALUATE OPERATION #" + OPCounter++ + " EVALUATING " + OPEvaluates + " ");
	}

  public static void OPReturn(String OPReturn) {
    System.out.println("RETURN OPERATION #" + OPCounter++ + " RETURNING: " + OPReturn + " ");
  }

  public static int increment(int a) {
    int output = a + 1;
    return output;
  }
}

/* 
PART 1: Algorithm PrefixAverages2(A, n):
* fallow the comments in code for OPERATION

Algorithm PrefixAverages2(A, n):
 Input: An integer array A of size n.
 Output: An array X of size n such that X[j] is the average of A[0], …, A[j].
 Let X be an integer array of size n
 runningSum <-- 0
 for j=0 to n-1 do
 runningSum <-- runningSum + A[k]
 X[j] <-- runningSum / (j+1)
 return X

 i. the output 155 
 ii. * fallow the comments for operation >> TOTAL OPERATIONS: 19

ASSIGN OPERATION #1 ASSIGNING: int minValueIndex = 0 
ASSIGN OPERATION #2 ASSIGNING: runningSum = 0 
ASSIGN OPERATION #3 ASSIGNING: int n = 6 
ASSIGN OPERATION #4 ASSIGNING: new int[n] to B 
ASSIGN OPERATION #5 ASSIGNING: First: Forloop: int j = 0 
ITERATE OPERATION #6 ITTERATING: runningSum = runningSum + A[j] : 5 
ITERATE OPERATION #7 ITTERATING: A[j] = runningSum/(j+1) : 5 
ITERATE OPERATION #8 ITTERATING: runningSum = runningSum + A[j] : 15 
ITERATE OPERATION #9 ITTERATING: A[j] = runningSum/(j+1) : 7 
ITERATE OPERATION #10 ITTERATING: runningSum = runningSum + A[j] : 35 
ITERATE OPERATION #11 ITTERATING: A[j] = runningSum/(j+1) : 11 
ITERATE OPERATION #12 ITTERATING: runningSum = runningSum + A[j] : 65 
ITERATE OPERATION #13 ITTERATING: A[j] = runningSum/(j+1) : 16 
ITERATE OPERATION #14 ITTERATING: runningSum = runningSum + A[j] : 105 
ITERATE OPERATION #15 ITTERATING: A[j] = runningSum/(j+1) : 21 
ITERATE OPERATION #16 ITTERATING: runningSum = runningSum + A[j] : 155 
ITERATE OPERATION #17 ITTERATING: A[j] = runningSum/(j+1) : 25 
EVALUATE OPERATION #18 EVALUATING LAST: j < n : 6 < 6 
RETURN OPERATION #19 RETURNING: return A : 155 

 iii. O(n)
 */