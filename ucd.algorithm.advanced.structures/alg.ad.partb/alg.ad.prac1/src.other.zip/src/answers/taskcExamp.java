import java.util.*;
import java.util.Scanner;

public class taskcExamp {
  public static void main(String[] args) {
    double duration = 0;
    for (int i = 0; i < 5; i++) {
      long start = System.currentTimeMillis();
      increment(5);
      long end = System.currentTimeMillis();
      duration += end - start;
    }
    duration = duration / 5;
    System.out.println("Running Time=" + duration);
	}

}
