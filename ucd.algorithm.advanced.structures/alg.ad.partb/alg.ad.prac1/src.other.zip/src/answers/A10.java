// import java.util.*;
// import java.util.Scanner;

// public class A10 {
// 	public static int OPCounter = 1;
// 	public static String OPDeclare;
// 	public static String OPAssign;
// 	public static String OPIterate;
// 	public static String Printall;

// 	public static void main(String args[]) {
// 		int n = 5;
// 		int[] A = new int[n];
// 		int q = 0; 

// 		int outLinear = LinearSearch(A, n, q);
// 		System.out.println("the output for the LinearSearch is " + outLinear);
// 	}

// 	public static int LinearSearch(int A[], int n, int q) {
// 		int index = 0;
// 		OPAssign("index = 0");
// 		while ((index < n) && (A[index] == q)) {
// 			index = index + 1;
// 			if (index == n) {
// 				return -1;
// 			} else {
// 				return index;
// 			}
// 		}
// 	}


//  /*
//  :'#######::'########::'########:'########:::::'###::::'########:'####::'#######::'##::: ##::'######::
//  '##.... ##: ##.... ##: ##.....:: ##.... ##:::'## ##:::... ##..::. ##::'##.... ##: ###:: ##:'##... ##:
//   ##:::: ##: ##:::: ##: ##::::::: ##:::: ##::'##:. ##::::: ##::::: ##:: ##:::: ##: ####: ##: ##:::..::
//   ##:::: ##: ########:: ######::: ########::'##:::. ##:::: ##::::: ##:: ##:::: ##: ## ## ##:. ######::
//   ##:::: ##: ##.....::: ##...:::: ##.. ##::: #########:::: ##::::: ##:: ##:::: ##: ##. ####::..... ##:
//   ##:::: ##: ##:::::::: ##::::::: ##::. ##:: ##.... ##:::: ##::::: ##:: ##:::: ##: ##:. ###:'##::: ##:
//  . #######:: ##:::::::: ########: ##:::. ##: ##:::: ##:::: ##::::'####:. #######:: ##::. ##:. ######::
//  :.......:::..:::::::::........::..:::::..::..:::::..:::::..:::::....:::.......:::..::::..:::......:::
// */

// 	public static void OPIterate(String OPIterate) {
// 		System.out.println("ITERATE OPERATION #" + OPCounter++ + " ITTERATING: " + OPIterate + " ");
// 	}

// 	public static void OPAssign(String OPAssign) {
// 		System.out.println("ASSIGN OPERATION #" + OPCounter++ + " ASSIGNING: " + OPAssign + " ");
// 	}

// 	public static void OPEvaluate(String OPEvaluates) {
// 		System.out.println("EVALUATE OPERATION #" + OPCounter++ + " EVALUATING " + OPEvaluates + " ");
// 	}

// 	public static void OPReturn(String OPReturn) {
// 		System.out.println("RETURN OPERATION #" + OPCounter++ + " RETURNING: " + OPReturn + " ");
// 	}
// }