// import java.util.*;
// import java.util.Scanner;

// public class A5 {
// 	public static int OPCounter = 1;
// 	public static String OPDeclare;
// 	public static String OPEvaluate;
// 	public static String OPAssign;
// 	public static String OPIterate;
// 	public static String OPReturn;
// 	public static String Printall;

// 	public static void main(String args[]) {

// 		int n = 5;
// 		int[] A = { 34, 77, 20, 30, 40, 50 };
// 		// int A[] = new int[n];
// 		int minoutput = MinValue(A, n);
// 		System.out.println("The MinValue OUTPUT IS: " + minoutput);
// 	}

// 	public static int MinValue(int A[], int n) {
// 		int minValue = A[0];
// 		OPAssign("minValue = A[0]");
// 		OPAssign("First: Forloop: int k = 1");
// 		for (int k = 1; k < n; k++) {
// 			OPAssign("int k = 1; k < n " + " : " + minValue);
// 			OPIterate("k++" + " : " + k);

// 			if (A[minValue] > A[k]) {
// 				minValue = k;
// 				OPEvaluate("A[minValue] > A[k] is TRUE : " + A[minValue] + " > " + A[k]);

// 			} else if (A[minValue] < A[k]) {
// 				OPEvaluate("A[minValue] < A[k] is TRUE : " + A[minValue] + " < " + A[k]);
// 			}
// 		}
// 		OPReturn("RETURNING: return minValue" + " : " + minValue);
// 		return minValue;
// 	}

	

// 	/*
// 	:'#######::'########::'########:'########:::::'###::::'########:'####::'#######::'##::: ##::'######::
// 	'##.... ##: ##.... ##: ##.....:: ##.... ##:::'## ##:::... ##..::. ##::'##.... ##: ###:: ##:'##... ##:
// 	##:::: ##: ##:::: ##: ##::::::: ##:::: ##::'##:. ##::::: ##::::: ##:: ##:::: ##: ####: ##: ##:::..::
// 	##:::: ##: ########:: ######::: ########::'##:::. ##:::: ##::::: ##:: ##:::: ##: ## ## ##:. ######::
// 	##:::: ##: ##.....::: ##...:::: ##.. ##::: #########:::: ##::::: ##:: ##:::: ##: ##. ####::..... ##:
// 	##:::: ##: ##:::::::: ##::::::: ##::. ##:: ##.... ##:::: ##::::: ##:: ##:::: ##: ##:. ###:'##::: ##:
// 	. #######:: ##:::::::: ########: ##:::. ##: ##:::: ##:::: ##::::'####:. #######:: ##::. ##:. ######::
// 	:.......:::..:::::::::........::..:::::..::..:::::..:::::..:::::....:::.......:::..::::..:::......:::
// 	*/

// 	public static void OPIterate(String OPIterate) {
// 		System.out.println("ITERATE OPERATION #" + OPCounter++ + " ITTERATING: " + OPIterate + " ");
// 	}

// 	public static void OPAssign(String OPAssign) {
// 		System.out.println("ASSIGN OPERATION #" + OPCounter++ + " ASSIGNING: " + OPAssign + " ");
// 	}

// public static void OPEvaluate(String OPEvaluates) {
// 	System.out.println("EVALUATE OPERATION #" + OPCounter++ + " EVALUATING " + OPEvaluates + " ");
// }

// 	public static void OPReturn(String OPReturn) {
// 		System.out.println("RETURN OPERATION #" + OPCounter++ + " RETURNING: " + OPReturn + " ");
// 	}
// }


// /* 
// PART 1: Algorithm MinValue(a, b):
// * fallow the comments in code for OPERATION

// ALGO MinValue(A, n):
//  Input: An integer array A of size n
//  Output: The smallest value in A
//  minValue <- A[0]
//  for k=1 to n-1 do
//  if (minValue > A[k]) then
//  minValue <- A[k]
//  return minValue

//  i. the output of ...
//  ii. * fallow the comments for operation >> TOTAL OPERATIONS: 






//  iii. O(n)
//  */