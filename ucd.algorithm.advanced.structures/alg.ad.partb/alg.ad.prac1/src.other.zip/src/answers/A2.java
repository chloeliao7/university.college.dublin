public class A2 {
  public static void main(String[] args) { 
		int a = 2;
		int b = 6;

		int outverage = Average(a, b); 
		System.out.println("the output of the average is: " + outverage);
	}
  public static int Average(int a, int b) { 
		return (a + b) / 2; 
		// operations add, devide and return = 3
  }
}

/* 
PART 1: Algorithm Average(a, b):
* fallow the comments in code for OPERATION

 Input: Two integers a and b
 Output: The average of a and b
 return (a + b) / 2 

 i. the output of the average is: 4
 ii. * fallow the comments for operation >> TOTAL OPERATIONS: 3
 iii. O(1)
 
 */