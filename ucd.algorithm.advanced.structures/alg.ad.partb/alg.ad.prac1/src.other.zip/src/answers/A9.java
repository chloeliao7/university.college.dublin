import java.util.*;
import java.util.Scanner;

public class A9 {
	public static int OPCounter = 1;
	public static String OPDeclare;
	public static String OPAssign;
	public static String OPIterate;
	public static String Printall;

	public static void main(String args[]) {
		int a = 2;
		int b = 3;
		int d = Power(a, b);
		System.out.println("the output is " + d);
	}

	public static int Power(int a, int b) {
		int power = 1;
		int k; 
		OPAssign("1 to variable power");
		OPEvaluate("FIRST Evaluation: Forloop: int k = 1");
		for (k = 1; k < b; k++) {
			power = power * a;
			OPAssign("power = power * a" + " power = " + power);
			OPIterate("ITERATING: k++" + " : " + k);
		}
		OPEvaluate("LAST: k < b" + " : " + k + " < " + b);
		OPReturn("return power" + " RETURN power = " + power);
		return power;
	}
	/*
	:'#######::'########::'########:'########:::::'###::::'########:'####::'#######::'##::: ##::'######::
	'##.... ##: ##.... ##: ##.....:: ##.... ##:::'## ##:::... ##..::. ##::'##.... ##: ###:: ##:'##... ##:
	##:::: ##: ##:::: ##: ##::::::: ##:::: ##::'##:. ##::::: ##::::: ##:: ##:::: ##: ####: ##: ##:::..::
	##:::: ##: ########:: ######::: ########::'##:::. ##:::: ##::::: ##:: ##:::: ##: ## ## ##:. ######::
	##:::: ##: ##.....::: ##...:::: ##.. ##::: #########:::: ##::::: ##:: ##:::: ##: ##. ####::..... ##:
	##:::: ##: ##:::::::: ##::::::: ##::. ##:: ##.... ##:::: ##::::: ##:: ##:::: ##: ##:. ###:'##::: ##:
	. #######:: ##:::::::: ########: ##:::. ##: ##:::: ##:::: ##::::'####:. #######:: ##::. ##:. ######::
	:.......:::..:::::::::........::..:::::..::..:::::..:::::..:::::....:::.......:::..::::..:::......:::
	*/

	public static void OPIterate(String OPIterate) {
		System.out.println("ITERATE OPERATION #" + OPCounter++ + " ITTERATING: " + OPIterate + " ");
	}

	public static void OPAssign(String OPAssign) {
		System.out.println("ASSIGN OPERATION #" + OPCounter++ + " ASSIGNING: " + OPAssign + " ");
	}

	public static void OPEvaluate(String OPEvaluates) {
		System.out.println("EVALUATE OPERATION #" + OPCounter++ + " EVALUATING " + OPEvaluates + " ");
	}

	public static void OPReturn(String OPReturn) {
		System.out.println("RETURN OPERATION #" + OPCounter++ + " RETURNING: " + OPReturn + " ");
	}
}

/* 
PART 1: Algorithm Factorial(a):
* fallow the comments in code for OPERATION

Algorithm Factorial(a):
 Input: An integer a
 Output: The value of a factorial (a!)
 factorial <-- 1
 for k=1 to a do
 factorial <-- factorial * k
 return factorial

 i. the output 4
 ii. * fallow the comments for operation >> TOTAL OPERATIONS: 8

ASSIGN OPERATION #1 ASSIGNING: 1 to variable power 
EVALUATE OPERATION #2 EVALUATING FIRST Evaluation: Forloop: int k = 1 
ASSIGN OPERATION #3 ASSIGNING: power = power * a power = 2 
ITERATE OPERATION #4 ITTERATING: ITERATING: k++ : 1 
ASSIGN OPERATION #5 ASSIGNING: power = power * a power = 4 
ITERATE OPERATION #6 ITTERATING: ITERATING: k++ : 2 
EVALUATE OPERATION #7 EVALUATING LAST: k < b : 3 < 3 
RETURN OPERATION #8 RETURNING: return power RETURN power = 4 
the output is 4

 iii. O(n)
 */
