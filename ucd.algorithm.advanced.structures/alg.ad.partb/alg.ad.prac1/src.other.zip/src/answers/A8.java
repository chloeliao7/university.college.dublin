import java.util.*;
import java.util.Scanner;

public class A8 {
	public static int OPCounter = 1;
	public static String OPDeclare;
	public static String OPAssign;
	public static String OPIterate;
	public static String Printall;

	public static void main(String args[]) {
		int a = 5;
		int d = Factorial(a);
		System.out.println("FACTORIAL OUTPUT IS: " + d);
	}

	public static int Factorial(int a) {
		double duration = 0;
		int k; 
		int factorial = 1;
		OPAssign("1 to factorial");
		OPEvaluate("First Evaluation: Forloop: inwt k = 1");
		for (k = 1; k < a; k++) {
			long start = System.currentTimeMillis();
			increment(a);
			factorial = factorial * k;
			OPAssign("factorial = factorial * k" + " : " + factorial);
			OPIterate("K++" + " : " + k);
			long end = System.currentTimeMillis();
			duration += end - start;
		}

		OPEvaluate("LAST: k < a" + " : " + k + " < " + a);
		OPReturn("return factorial" + " : " + factorial);
		duration = duration / 5;
		System.out.println("Running Time=" + duration);
		return factorial;
	}

	/*
	:'#######::'########::'########:'########:::::'###::::'########:'####::'#######::'##::: ##::'######::
	'##.... ##: ##.... ##: ##.....:: ##.... ##:::'## ##:::... ##..::. ##::'##.... ##: ###:: ##:'##... ##:
	##:::: ##: ##:::: ##: ##::::::: ##:::: ##::'##:. ##::::: ##::::: ##:: ##:::: ##: ####: ##: ##:::..::
	##:::: ##: ########:: ######::: ########::'##:::. ##:::: ##::::: ##:: ##:::: ##: ## ## ##:. ######::
	##:::: ##: ##.....::: ##...:::: ##.. ##::: #########:::: ##::::: ##:: ##:::: ##: ##. ####::..... ##:
	##:::: ##: ##:::::::: ##::::::: ##::. ##:: ##.... ##:::: ##::::: ##:: ##:::: ##: ##:. ###:'##::: ##:
	. #######:: ##:::::::: ########: ##:::. ##: ##:::: ##:::: ##::::'####:. #######:: ##::. ##:. ######::
	:.......:::..:::::::::........::..:::::..::..:::::..:::::..:::::....:::.......:::..::::..:::......:::
	*/

	public static void OPIterate(String OPIterate) {
		System.out.println("ITERATE OPERATION #" + OPCounter++ + " ITTERATING: " + OPIterate + " ");
	}

	public static void OPAssign(String OPAssign) {
		System.out.println("ASSIGN OPERATION #" + OPCounter++ + " ASSIGNING: " + OPAssign + " ");
	}

	public static void OPEvaluate(String OPEvaluates) {
		System.out.println("EVALUATE OPERATION #" + OPCounter++ + " EVALUATING " + OPEvaluates + " ");
	}

	public static void OPReturn(String OPReturn) {
		System.out.println("RETURN OPERATION #" + OPCounter++ + " RETURNING: " + OPReturn + " ");
	}

	public static int increment(int a) {
		int output = a + 1;
		return output;
	}
}

/* 
PART 1: Algorithm Factorial(a):
* fallow the comments in code for OPERATION

Algorithm Factorial(a):
 Input: An integer a
 Output: The value of a factorial (a!)
 factorial <-- 1
 for k=1 to a do
 factorial <-- factorial * k
 return factorial

 i. the output 24
 ii. * fallow the comments for operation >> TOTAL OPERATIONS: 12

ASSIGN OPERATION #1 ASSIGNING: 1 to factorial 
EVALUATE OPERATION #2 EVALUATING First Evaluation: Forloop: inwt k = 1 
ASSIGN OPERATION #3 ASSIGNING: factorial = factorial * k : 1 
ITERATE OPERATION #4 ITTERATING: K++ : 1 
ASSIGN OPERATION #5 ASSIGNING: factorial = factorial * k : 2 
ITERATE OPERATION #6 ITTERATING: K++ : 2 
ASSIGN OPERATION #7 ASSIGNING: factorial = factorial * k : 6 
ITERATE OPERATION #8 ITTERATING: K++ : 3 
ASSIGN OPERATION #9 ASSIGNING: factorial = factorial * k : 24 
ITERATE OPERATION #10 ITTERATING: K++ : 4 
EVALUATE OPERATION #11 EVALUATING LAST: k < a : 5 < 5 
RETURN OPERATION #12 RETURNING: return factorial : 24 

 iii. O(n)
 */
