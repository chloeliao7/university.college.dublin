package com.javainuse.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Employee;
import com.javainuse.model.data.EmployeeRepository;

@RestController
public class TestController {

	@Autowired
	private EmployeeRepository repository;


	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public Employee firstPage() {

		Employee emp = new Employee();
		emp.setFirstName("eoin");
		emp.setLastName("goslin");
		emp.setDesignation("manager");
		emp.setEmpId("1");
		emp.setSalary(3000);
		Employee secondEmp = new Employee();
		secondEmp.setFirstName("John");
		secondEmp.setLastName("Doe");
		secondEmp.setDesignation("unsure");
		secondEmp.setEmpId("2");
		secondEmp.setSalary(1000);


		//employee now created, store in MongoDb
		repository.deleteAll();

		// save a couple of customers
		repository.save(emp);
		repository.save(secondEmp);

		// fetch all customers
		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Employee employee : repository.findAll()) {
			System.out.println(employee);
		}
		System.out.println();

		// fetch an individual customer
		System.out.println("Customer found with findByFirstName('eoin'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByFirstName("eoin"));

		System.out.println("Customers found with findByLastName('Doe'):");
		System.out.println("--------------------------------");
		for (Employee customer : repository.findByLastName("Doe")) {
			System.out.println(customer);
		}



		return emp; //prints it on screen if go to /employee
	}

}
