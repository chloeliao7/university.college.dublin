package com.javasampleapproach.gridfstemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataGridFsTemplateApplication{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataGridFsTemplateApplication.class, args);
	}
}
