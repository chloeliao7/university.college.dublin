package com.squidit.web.web;

import com.squidit.web.model.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebVideoController {
    // Client controller, fetches Account info from the microservice via {@link WebAccountsService}.
    @Autowired
    private WebVideoService videoService;

    public WebVideoController(WebVideoService videoService) {
        this.videoService = videoService;
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setAllowedFields("videoId", "searchText");
    }

    @RequestMapping("/video")
    public String goHome() {
        return "index";
    }

    @RequestMapping("/video/{videoId}")
    public String byNumber(Model model, @PathVariable("videoId") String videoId) {
        Video video = videoService.findById(videoId);
        model.addAttribute("video", video);
        return "video";
    }
}