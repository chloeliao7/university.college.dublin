package com.squidit.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * Will be Mongo web-server. Works as a microservice client, fetching data from the
 * MongoDatabases. Uses the Discovery Server (Eureka) to find the microservice.
 *
 * @author Eoin Goslin and Greg Cousin
 */

@SpringBootApplication
@EnableDiscoveryClient
public class WebApplication {

    // A customized RestTemplate that has the ribbon load balancer build in. Note that prior to the "Brixton"
    @LoadBalanced
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    // Run the application using Spring Boot and an embedded servlet engine.
    public static void main(String[] args) {
        SpringApplication.run(WebApplication.class, args);
    }
}
