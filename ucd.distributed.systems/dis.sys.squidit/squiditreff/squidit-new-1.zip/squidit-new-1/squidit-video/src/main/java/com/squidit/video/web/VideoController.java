package com.squidit.video.web;

import com.squidit.video.model.Video;
import com.squidit.video.service.VideoService;
import com.squidit.video.web.dto.VideoRequestDto;
import com.squidit.video.web.dto.VideoResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class VideoController {

    private VideoService videoService;

    @Autowired
    public VideoController(VideoService videoService) {
        this.videoService = videoService;
    }

    @GetMapping("/video/{videoId}")
    public ResponseEntity<VideoResponseDto> getVideo(@PathVariable String videoId) {
        Optional<Video> video = videoService.findVideo(videoId);

        return video.map(v -> new ResponseEntity<>(mapVideoToVideoResponse(v), HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(null, HttpStatus.NOT_FOUND));
    }

    @GetMapping("/video/owner/{ownerId}")
    public ResponseEntity<List<VideoResponseDto>> getVideosByOwnerId(@PathVariable String ownerId) {
        List<Video> videosByOwnerId = videoService.findVideosByOwnerId(ownerId);

        List<VideoResponseDto> videoResponseDtos = videosByOwnerId.stream()
                .map(this::mapVideoToVideoResponse)
                .collect(Collectors.toList());

        return new ResponseEntity<>(videoResponseDtos, HttpStatus.OK);
    }

    @PostMapping("/video")
    public ResponseEntity<VideoResponseDto> createVideo(@RequestBody VideoRequestDto videoRequestDto) {
        Video video = mapVideoRequestToVideo(videoRequestDto);

        Video createdVideo = videoService.createVideo(video);

        return new ResponseEntity<>(mapVideoToVideoResponse(createdVideo), HttpStatus.CREATED);
    }

    private VideoResponseDto mapVideoToVideoResponse(Video video) {
        VideoResponseDto responseDto = new VideoResponseDto();
        responseDto.setVideoId(video.getVideoId());
        responseDto.setOwnerId(video.getOwnerId());
        responseDto.setName(video.getName());
        return responseDto;
    }

    private Video mapVideoRequestToVideo(VideoRequestDto videoRequestDto) {
        Video video = new Video();
        video.setOwnerId(videoRequestDto.getOwnerId());
        video.setName(videoRequestDto.getName());
        return video;
    }

}
