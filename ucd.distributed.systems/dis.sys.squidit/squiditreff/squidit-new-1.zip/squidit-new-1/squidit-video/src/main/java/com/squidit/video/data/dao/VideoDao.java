package com.squidit.video.data.dao;

import com.squidit.video.data.repository.VideoRepository;
import com.squidit.video.model.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class VideoDao {

    private VideoRepository videoRepository;

    @Autowired
    public VideoDao(VideoRepository videoRepository) {
        this.videoRepository = videoRepository;
    }

    public Optional<Video> findVideo(String videoId) {
        return videoRepository.findById(videoId);
    }

    public List<Video> findVideosByOwnerId(String ownerId) {
        return videoRepository.findByOwnerId(ownerId);
    }

    public Video saveVideo(Video video) {
        return videoRepository.save(video);
    }
}
