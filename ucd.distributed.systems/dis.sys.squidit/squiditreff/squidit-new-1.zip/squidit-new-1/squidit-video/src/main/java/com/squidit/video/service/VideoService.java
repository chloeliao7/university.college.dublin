package com.squidit.video.service;

import com.squidit.video.data.dao.VideoDao;
import com.squidit.video.model.Video;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VideoService {

    private VideoDao videoDao;

    public VideoService(VideoDao videoDao) {
        this.videoDao = videoDao;
    }

    public Optional<Video> findVideo(String videoId) {
        return videoDao.findVideo(videoId);
    }

    public List<Video> findVideosByOwnerId(String ownerId) {
        return videoDao.findVideosByOwnerId(ownerId);
    }

    public Video createVideo(Video video) {
        return videoDao.saveVideo(video);
    }

}
