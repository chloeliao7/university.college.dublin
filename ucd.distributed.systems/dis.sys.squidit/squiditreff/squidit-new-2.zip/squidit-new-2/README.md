To run this application now run:
---------------------------------------------
java -jar target/application-0.0.1-SNAPSHOT.jar eureka
---------------------------------------------

This starts on registration server which turns on Eureka server so clients can then connect

To run video server after the first registration is running, enter:
---------------------------------------------
java -jar target/application-0.0.1-SNAPSHOT.jar video
---------------------------------------------

This starts on video server on port 2222

To run web server after the first registration is running, enter:
---------------------------------------------
java -jar target/application-0.0.1-SNAPSHOT.jar web
---------------------------------------------

This starts on web server on port 3333

visit localhost:1111 for eureka
visit localhost:3333 for the application

REST requests can be made to localhost:2222 for the video server

