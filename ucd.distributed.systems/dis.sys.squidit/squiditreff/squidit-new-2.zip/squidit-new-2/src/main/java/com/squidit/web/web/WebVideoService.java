package com.squidit.web.web;

import com.squidit.web.model.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

// Hide the access to the microservice inside this local service.

@Service
public class WebVideoService {
    private static final String VIDEO_SERVICE_URL = "http://VIDEO-SERVICE";

    @LoadBalanced
    private RestTemplate restTemplate;

    @Autowired
    public WebVideoService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Video findById(String videoId) {
        return restTemplate.getForObject(VIDEO_SERVICE_URL + "/video/{videoId}", Video.class, videoId);
    }
}
