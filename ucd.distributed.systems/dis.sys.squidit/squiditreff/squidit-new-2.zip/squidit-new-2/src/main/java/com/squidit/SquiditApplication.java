package com.squidit;

import com.squidit.eureka.EurekaApplication;
import com.squidit.video.VideoApplication;
import com.squidit.web.WebApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SquiditApplication {
    public static void main(String[] args) {

        String serverName = "NO-VALUE";

        switch (args.length) {
            case 1:
                serverName = args[0].toLowerCase();
                break;
            case 2:
                System.setProperty("server.port", args[1]);
            default:
                usage();
                return;
        }

        /*
         *
         * Fall through into ..
         * Optionally set the HTTP port to listen on, overrides
         * value in the <server-name>-server.yml file
         */

        switch (serverName) {
            case "eureka":
                EurekaApplication.main(args);
                break;
            case "video":
                VideoApplication.main(args);
                break;
            case "web":
                WebApplication.main(args);
                break;
            default:
                System.out.println("Unknown server type: " + serverName);
                usage();
                break;
        }
    }

    protected static void usage() {
        System.out.println("Usage: java -jar ... <server-name> [server-port]");
        System.out.println("     where server-name is 'eureka', "
                + "'video' or 'web' and server-port > 1024");
    }
}
