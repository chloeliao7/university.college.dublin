
package rmiproject.registry;

public interface Service { 

}

