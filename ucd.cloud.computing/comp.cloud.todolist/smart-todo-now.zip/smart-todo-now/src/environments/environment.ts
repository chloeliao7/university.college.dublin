// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyDwLBYYYSvkxVkq3y0Lre2Kj3d5k7sXfOc",
    authDomain: "todolist-ab9bd.firebaseapp.com",
    databaseURL: "https://todolist-ab9bd.firebaseio.com",
    projectId: "todolist-ab9bd",
    storageBucket: "todolist-ab9bd.appspot.com",
    messagingSenderId: "535059922933"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
