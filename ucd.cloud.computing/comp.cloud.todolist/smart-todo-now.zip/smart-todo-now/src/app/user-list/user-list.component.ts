import { UserService } from "./../services/user.service";
import { Component, OnInit } from "@angular/core";
@Component({
  selector: "app-user-list",
  templateUrl: "./user-list.component.html",
  styleUrls: ["./user-list.component.scss"]
})
export class UserListComponent implements OnInit {
  userList: any;
  constructor(private userService: UserService) {}
  ngOnInit() {
    this.userService.userList().subscribe(users => {
      this.userList = users;
    });
  
  }
  deleteUser(user) {
    this.userService.deleteUser(user);
  }
}
