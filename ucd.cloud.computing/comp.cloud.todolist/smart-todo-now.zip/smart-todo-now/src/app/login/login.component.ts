import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { UserService } from '../services/user.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: any;

  constructor(public userService: UserService, public authService: AuthService, private router: Router, private fb: FormBuilder) {
    this.loginForm = this.fb.group({
      email: ['email', Validators.required],
      password: ['pass', Validators.required]
    });
   }

  ngOnInit() {
  }

  // loging using twitter
  login(value) {
    this.userService.userExists(value.email).subscribe(userData => {
      if(userData.length > 0){
        this.userService.login("app", value).then(
          (user: { uid: string }) => { 
            // typescript unlike javascript needs to do the refference of the object and cannot find it 
            this.router.navigate(['/todos']).then(function(){
              location.reload();
            });
          },
          err => {
            console.log(err);
            // this.errorMessage = err.message;
          }
        );
      }
    });
  }

  // loging using google
  googleLogin() {
    this.userService.login('google');
  }



}
