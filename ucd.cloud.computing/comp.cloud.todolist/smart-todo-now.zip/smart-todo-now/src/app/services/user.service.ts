import { Injectable } from "@angular/core";
import { AngularFireAuth } from "angularfire2/auth";
import { AuthService } from "./auth.service";
import { map } from "rxjs/operators";
import { auth } from "firebase/app";
import { AngularFireList, AngularFireDatabase } from "angularfire2/database";
import { Router } from "@angular/router";
import * as firebase from "firebase";

@Injectable()
export class UserService {
  
  uid = this.afAuth.authState.pipe(
    map(authState => {
      if (!authState) {
        return null;
      } else {
        return authState.uid;
      }
    })
  );

  email = this.afAuth.authState.pipe(
    map(authState => {
      if (!authState) {
        return null;
      } else {
        return authState.email;
      }
    })
  );

  user: AngularFireList<any>;
  userLength: any;

  constructor(public authServ: AuthService, private router: Router, public db: AngularFireDatabase, public afAuth: AngularFireAuth) {}

  // login method
  login(method: string, value?) {
    console.log(value, "from user service login");
    let callback;
    switch (method) {
      case "google":
        callback = this.googleLogin();
        break;
        case 'app':
        callback = this.doLogin(value);
        break;
    }
    return callback;
  }

  doLogin(value) {
    return new Promise<any>(
      (resolve, reject) => {
        // signins if the user exists in auth
        firebase.auth()
          .signInWithEmailAndPassword(value.email, value.password)
          .then(
            // on success
            (answer) => {
              const user = answer.user;
              this.uid;
              resolve(user);
            },
            // on failure
            err => {
              // creates auth user if not exists in auth
              firebase.auth().createUserWithEmailAndPassword(value.email, value.password).then(
                (answer) => {
                  const user = answer.user;
                  this.uid;
                  resolve(user);
                },
                // on failor
                error => {
                  reject(error);
                }
              );
              
            }
          );
      }
    )
  }

  // checks if user exists
  userExists(email: any): any {
    return this.db.list('/users', ref => ref.orderByChild("email").equalTo(email)).valueChanges();
  }

  // get the user list from database
  userList(): any {
    return this.db.list("users").valueChanges();
  }

  // delete a specific user from database
  deleteUser(key: any): any {
    this.user = this.db.list("users");
    this.user.remove(key);
  }

  // create new user and add in database using angular fire auth createUserWithEmailAndPassword method
  addNewUser(user: any): any {
    this.user = this.db.list("users");
    this.user.push({
      uid: "",
      displayName: user.displayName,
      email: user.email,
      password: user.password,
      emailVerified: false,
      photoURL: ""
    });
    return this.user.valueChanges();
  }

  // login using angular fire auth signInWithPopup and google auth provider
  googleLogin() {
    this.user = this.db.list("users");
    this.afAuth.auth.signInWithPopup(new auth.GoogleAuthProvider()).then(data => {
      // inserted data into user table after login
      this.userExists(data.user.email).subscribe(userData => {
        if(userData.length < 1){
          this.user.push({
            uid: data.user.uid,
            displayName: data.user.displayName,
            email: data.user.email,
            emailVerified: data.user.emailVerified,
            photoURL: data.user.photoURL
          });
        }
        this.uid;
      });

      this.router.navigate(['/todos']).then(function(){
        location.reload();
      });
    }, err => {
      console.log(err);
      this.router.navigate(['/login']);

    });
  }

  // logged out using augularfire auth signout method
  doLogout() {
    return new Promise((resolve, reject) => {
      if (firebase.auth().currentUser) {
        this.afAuth.auth.signOut()
        resolve();
      } else {
        reject();
      }
      this.uid = null;
      this.email = null;
      this.router.navigate(['/']).then(() => {
        location.reload();
      });
    });
  }
  
}
