import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AngularFireDatabase } from 'angularfire2/database';
import { firestore } from 'firebase';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  
  modalForm: any;
  todo: any;
  todoList: any;
  sharedTodo: any;

  constructor(private firebasedb: AngularFireDatabase) { 
    this.modalForm = new FormGroup({
      email : new FormControl('', Validators.email),
    });
  }

  // add a todo
  addTitle(title: any, uid: any, email: any): any {
    this.todo = this.firebasedb.list('/todos');
    var month = new Date().getMonth() + 1;
    this.todo.push({
      title: title,
      uid: uid,
      email: email,
      created_by: email,
      shared_with: email,
      // timestamp
      created_at: new Date().getDate() + ':' + month + ':' + new Date().getFullYear(),
      // timestamp
      updated_at: firestore.Timestamp.now(),
      isChecked: false
    });
  }

  // get todos by uid
  getTodoList(userId) {
    return this.firebasedb.list('/todos', ref => ref.orderByChild("uid").equalTo(userId));
  }

  // get todos by email
  getTodoListByEmail(email) {
    return this.firebasedb.list('/sharedtodos', ref => ref.orderByChild("email").equalTo(email));
  }

  // update a todo
  updateTodo(todo: any): any {
    this.todo = this.firebasedb.list('/todos');
    this.todo.update(todo.$key, { title : todo.title, updated_at: new Date() });
    location.reload();

  }

  // delete a todo
  deleteTodo(key: any): any {
    this.todo = this.firebasedb.list('/todos');
    this.todo.remove(key);
  }




 
  // share all the todos
  // shareTodo(email: any, userId: any): any {
  shareTodo(email: any, userId: any): any {

    var sharedTodo = this.firebasedb.list('/sharedtodos');
    var month = new Date().getMonth() + 1;


    
    this.getTodoList(userId).valueChanges().subscribe((data) :any => {
      console.log(data);
      this.todoList = data;
      this.todoList.forEach(function(value){
        console.log(value);
        sharedTodo.push({
          // title: value.title,
          // uid: userId,
          // email: email,
          // isChecked: false
          title: value.title,
          uid: userId,
          email: email,
          created_by: email,
          shared_with: email,
          // timestamp
          created_at: new Date().getDate() + ':' + month + ':' + new Date().getFullYear(),
          // timestamp
          updated_at: firestore.Timestamp.now(),
          isChecked: false
        });
      });
    });
  }
}
