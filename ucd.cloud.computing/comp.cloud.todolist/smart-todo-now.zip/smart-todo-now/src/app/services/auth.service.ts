import { UserService } from './user.service';
import {Injectable} from '@angular/core';
import {AngularFireAuth} from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import { Router } from '@angular/router';


@Injectable()
export class AuthService {
  user: {};
  constructor(public afAuth: AngularFireAuth, public router: Router) {}

  doLogin(value) {
    return new Promise<any>(
      (resolve, reject) => {
        console.log(value, 'do login ');
        firebase.auth()
          .signInWithEmailAndPassword(value.email, value.password)
          .then(
            // on success
            (answer) => {
              const user = answer.user;
              console.log('do login success', user)
              this.user = user;
              resolve(user);
            },
            // on failure
            err => {
              firebase.auth().createUserWithEmailAndPassword(value.email, value.password).then(
                (answer) => {
                  const user = answer.user;
                  console.log('do login success', user)
                  this.user = user;
                  resolve(user);
                },
                error => {
                  reject(err);
                }
              );
              
            }
          );
      }
    )
  }


  
}
