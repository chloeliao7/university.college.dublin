export class User {
    uid: string;
    displayName: string;
    email: string;
    password: string;
    emailVerified: boolean;
    photoURL: string;
}