export class Todo {
    title: string;
    uid: string;
    email: string;
    created_by:string;
    shared_with:string;
    created_at: string;
    isChecked: boolean;
}