import { AngularFireDatabase } from 'angularfire2/database';
import { Component, OnInit } from '@angular/core';
import { TodoService } from '../services/todo.service';
import { UserService } from '../services/user.service';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.scss']
})
export class TodoListComponent implements OnInit {
  userId: string;
  userEmail: string;
  todoList: any;
  searchterm:string;
  searchText: string;
  startAt = new Subject();
  endAt = new Subject();
  startobs = this.startAt.asObservable();
  endobs = this.startAt.asObservable();

  constructor(private todoService: TodoService, private userService: UserService, private afdb: AngularFireDatabase) {
    if(this.userService.uid != null){
      this.userService.uid.subscribe( data => { 
        this.userId = data;
      });
  
      this.userService.email.subscribe( data => { 
        this.userEmail = data;
      });
    }
   }

     // replication of todolist but more globa: needs uid, checks and updates all todos in the list.
  ngOnInit() {
    if(this.userService.uid != null){
      this.userService.uid.subscribe( data => { 
        this.userId = data;
        this.todoService.getTodoList(this.userId).snapshotChanges().subscribe(item => {
          this.todoList = item;
          this.todoService.getTodoListByEmail(this.userEmail).snapshotChanges().subscribe(d => {
            var data = item.concat(d);
            this.todoList = data.map(val => {
              return {
                $key : val.key,
                ...val.payload.val()
              }
            });
          });
          this.todoList.sort((a, b) => {
            return a.isChecked - b.isChecked;
          });
        });
      });
    }
  }

   // delete a todo
   onDelete(key){
    this.todoService.deleteTodo(key);
  }
  search(searchTerm){
    this.afdb.list('todos', ref => ref.startAt(searchTerm).orderByChild('title')).valueChanges()
    .subscribe(data => {
      console.log(data, "after search");
      this.todoList = data;
    });
    // console.log(value);
  }
}
