import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navhead',
  templateUrl: './navhead.component.html',
  styleUrls: ['./navhead.component.scss']
})
export class NavheadComponent implements OnInit {
  userId: string;

  constructor(private userService: UserService, private authService: AuthService, private route: Router) {
    if(this.userService.uid != null){
      this.userService.uid.subscribe( data => { 
        // get the user id and check in html for login/logout toggle
        this.userId = data;
      });
    }
   }

  ngOnInit() {
  }

  // logout method called from auth service.
  logout(){
    this.userService.doLogout();
  }

}
