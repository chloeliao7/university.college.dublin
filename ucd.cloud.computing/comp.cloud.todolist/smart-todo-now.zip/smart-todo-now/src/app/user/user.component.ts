import { User } from "./../models/user";
import { UserService } from "./../services/user.service";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthService } from "../services/auth.service";

@Component({
  selector: "app-user",
  templateUrl: "./user.component.html",
  styleUrls: ["./user.component.scss"]
})
export class UserComponent implements OnInit {
  user = new User();

  constructor(private userService: UserService, public authService: AuthService, public router: Router) {}

  ngOnInit() {}

  addNewUser(user) {
    this.userService.userExists(user.email).subscribe(userData => {
      if(userData.length < 1){ 
        this.userService.addNewUser(user).subscribe(data => {
          console.log(data);
          
          this.router.navigate(["/login"]);
        });
      } else {        
      }
    })
    
  }
}
