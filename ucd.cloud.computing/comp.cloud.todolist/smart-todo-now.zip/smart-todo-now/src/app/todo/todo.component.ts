import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { AngularFireDatabase } from 'angularfire2/database';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { TodoService } from '../services/todo.service';
import { Todo } from '../models/todo';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.scss']
})

export class TodoComponent implements OnInit {
  closeResult: string;
  userId: string;
  todoList: any;
  userEmail: string;
  // sharedtodo: any; 
  todo = new Todo();
  searchText: string;
  visibleTodoList: any[];

  constructor(private modalService: NgbModal, private fireDb: AngularFireDatabase, private todoService: TodoService, private userService: UserService) {
    
    if(this.userService.uid != null){
      // get the user id
      this.userService.uid.subscribe( data => { 
        this.userId = data;
      });
 
      // get the user email
      this.userService.email.subscribe( data => { 
        this.userEmail = data;
      });
    }
   }

  ngOnInit() {

    if(this.userService.uid != null){
    // get all the todo list created by user and shared with user
      this.userService.uid.subscribe(data => {
        this.userId = data;
        this.todoService.getTodoList(this.userId).snapshotChanges().subscribe(item => {
            this.todoList = item;
            this.todoService.getTodoListByEmail(this.userEmail).snapshotChanges().subscribe(d => {
                var data = item.concat(d);
                this.todoList = data.map(val => {
                  return {
                    $key: val.key,
                    ...val.payload.val()
                  };
                });
                this.visibleTodoList = [...this.todoList];
              });
            this.todoList.sort((a, b) => {
              return a.isChecked - b.isChecked;
            });
          });
      });
    }
  }

  // search todo
  search() {
    // console.log('searchText',this.searchText); // console.log(this.visibleTodoList)
    if (this.searchText) {
      this.visibleTodoList = [...this.todoList.filter(({ title }) => title === this.searchText)];
    } else {
      this.visibleTodoList = [...this.todoList];
    }
  }

  // insert todo into database
  onAdd(todo) {
    if(todo != undefined)
        this.todoService.addTitle(todo, this.userId, this.userEmail);
    todo = null;
  }

  // check and uncheck a todo to delete and update
  checkTodo(data){
    this.todoList.forEach(function(value){
      if(data.$key == value.$key){
        if(value.isChecked == false)
            value.isChecked = true;
        else
            value.isChecked = false;
      }
    });
  }

  // update a todo
  updateTodo(todo){
    this.todoService.updateTodo(todo);
    this.todo = null;
    location.reload();
  }

  // if its checked
  selectTodo(todo){
    if(todo.isChecked)
        this.todo = todo;
  }

  // delete a todo
  deleteTodo(key){
    this.todoService.deleteTodo(key);
  }

  // share all todos
  onModalFormSubmit(email){
    this.todoService.shareTodo(email, this.userId);
    this.modalService.dismissAll('Save click');
  }

  // open modal for sharing 
  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  // dismiss the modal
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
}
