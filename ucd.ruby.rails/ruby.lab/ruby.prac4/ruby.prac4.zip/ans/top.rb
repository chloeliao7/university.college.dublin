require_relative './book'
require_relative './user'
require_relative './library'


#try to take out one of the books here and it will tell you that the book cant be accessable 
# thesecretwindow = Book.new(name: 'thesecretwindow', author:'smddzcy') 

# Other Books
cosmeticstories = Book.new(name: 'cosmeticstories', author: 'warlord 3rd')
artstil = Book.new(name: 'artstil', author: 'frankenstein')
constenstein = Book.new(name: 'constenstein', author: 'camelot')
murdertales = Book.new(name: 'murdertales', author: 'weirdguy')

library = Library.new(books: [thesecretwindow, cosmeticstories, artstil, constenstein, murdertales])

theif = User.new(name: 'theif', library: library)
police = User.new(name: 'police', library: library)
rambo = User.new(name: 'rambo', library: library)

theif.borrow('thesecretwindow')
police.borrow('cosmeticstories') 
rambo.borrow('artstil') 
rambo.borrow('constenstein') 
rambo.borrow('murdertales')
