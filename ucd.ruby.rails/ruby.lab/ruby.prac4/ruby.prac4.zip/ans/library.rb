require_relative './book'
require_relative './user'

class Library
  attr_accessor :books

  def initialize(opts={})
    @books = opts[:books]
  end

  def lend(book_name, user)
    book = @books.find {|x| x.name == book_name }
    unless book.nil?
      book.borrowed_by = user
    else
      puts "Book couldn't be found"
    end
  end

  def book_is_available?(book_name)
    # check if there's a book with the book_name
    # if there isn't, .find will return nil
    # rails you can call .present? on nill objects directly
    not @books.find {|x| x.name == book_name }.nil?
  end

  def books_borrowed_by(user) 
  end
end
