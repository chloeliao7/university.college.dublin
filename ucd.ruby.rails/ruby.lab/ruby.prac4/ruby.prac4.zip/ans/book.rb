require_relative './library'

class Book
  attr_reader :name # we dont want others to change the names 
  attr_accessor :borrowed_by 
  def initialize(opts={})
    @name = opts[:name]
    @author = opts[:author]
  end
end


  


