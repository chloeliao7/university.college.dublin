require_relative './book'
require_relative './library'


class User
  def initialize(opts={})
    @name = opts[:name]
    @library = opts[:library]
    # puts opts = checking 
  end

  def borrow(book_name)
    if @library.book_is_available?(book_name)
      @library.lend(book_name, @name) # we pass the users's name to the library 
    else
      puts "Sorry but #{book_name} is not available"
    end
  end

  def return(book_name)
  end

  def borrowed_books
    @library.books_borrowed_by(@name) # The library knows what borrowed
  end
end
