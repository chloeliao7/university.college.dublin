require_relative './book'
require_relative './user'

class Library
  @books
  def initialize(books:); end

  def lend(_book_name, user)
    @book.borrowed_by = user
  end

  
  
  
  def book_is_available?(_book_name)
     @books.borrowed_by.nil?
  end
 
  def books_borrowed_by(user); end
end


