require_relative './user'
require_relative './library'


class Book
  attr_accessor :borrowed_by 
  def initialize(name:, author:)
    @name = name
    @author = author
  end
  
end


  


  

