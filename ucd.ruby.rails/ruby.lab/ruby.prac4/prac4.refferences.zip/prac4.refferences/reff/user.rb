require_relative './book'
require_relative './library'
class User
  def initialize(name, library)
    @name = name
    @library = library
  end

  def borrow(book_name)
    if @library.book_is_available?(book_name)
      @library.lend(book_name, @name)
    else
      puts "Sorry but #{book_name} is not available"
    end
  end

  def return(book_name); end

  def borrowed_books
    @library.books_borrowed_by(@name)
  end
end
