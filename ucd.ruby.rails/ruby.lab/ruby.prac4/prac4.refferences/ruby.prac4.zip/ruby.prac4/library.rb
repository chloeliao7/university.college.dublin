require_relative './top'

class Library
  # Should define a library class that has attributes that record
  # the books in the library, those books that have been borrowed,
  #  and those books available for borrowing.
  attr_accessor :allbooks, :borrowedbooks, :availablebooks

  def initialize(allbooks:, borrowedbooks:, availablebooks:)
    @allbooks = allbooks
    @borrowedbooks = borrowedbooks
    @availablebooks = availablebooks
	end

	def allbooks?
		# thesecretwindow
		# cosmeticstories
		# artstil
		# constenstein
		# murdertales
  end

	def borrowedbooks?
		
  end

  def availablebooks?
    # @bid.to_i == 20
  end

    # def librarydetails_arr=(name_array)
    #   @allbooks = allbooks[1]
    #   @borrowedbooks = borrowedbooks[2]
    #   @availablebooks = availablebooks[3]
    # end

  def librarydetails_arr
    'LIBRARY, WHO HAS THE BOOKS: ' + @allbooks + @borrowedbooks + @availablebooks
  end

  def printalllibrary_details
    puts "#{@allbooks}, #{@borrowedbooks}, #{@availablebooks}"
  end
end
