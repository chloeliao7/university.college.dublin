require_relative "./Book"
require_relative "./user"
require_relative "./library"

# create books 
thesecretwindow = Book.new(title: "thesecretwindow",author:"shakespear", uid: 122, page: 500, markbook: "P: and there was light")
cosmeticstories = Book.new(title: "cosmeticstories", author:"warlord 3rd", uid: 345,page: 233, markbook:"P: put MAKEUP!")
artstil = Book.new(title: "artstil", author: "frankenstein", uid: 345, page: 233, markbook: "P: put MAKEUP!")
constenstein = Book.new(title: "constenstein",author:"camelot",uid: 66, page: 111, markbook: "P: hide in your whole!")
murdertales = Book.new(title: "murdertales", author: "weirdguy", uid: 2, page: 2315, markbook: "P: plot twist")

p "print all books: "
[thesecretwindow, cosmeticstories, artstil, constenstein, murdertales].each do |book_|
		puts book_.inspect
	end
puts "\n"

# update books 
p "update books: "
# murdertales.booksystem_arr = [title: "savetales", author: "coolguy", uid: 233, page: 3902, markbook: "P: plot twist"]
# what is the difference? between these two 
# p murdertales.booksystem_arr 
murdertales.printallbooks_details
#  BOOKS TO BORROW HERE: ---------------------------------------------> 
puts "\n"
 
# create borrowers
p "create borrowers: "
theif = user.new(name: "harrypotter", address: "kyle", bid: 43)
police = user.new(name: "tomwainer", address: "steve",  bid:911)
rambo = user.new(name: "walin", address: "out", bid: 33)

# print all borrowers
p "print all borrowers: "
[theif, police, artstil, rambo].each do |borrowers_|
		puts borrowers_.inspect
	end
puts "\n"

# print all book borrower details 
p "borrowers details: "
p theif.printallborrowers_details
p police.printallborrowers_details
p rambo.printallborrowers_details
puts "\n"

# update book borrower
p "update book borrower: "
# theif.bookborrowdetails_arr = ["IT", "TOM", 34]
p theif.bookborrowdetails_arr
puts "\n"

#updated theif details
p "updated book borrower NEW: "
theif.printallborrowers_details
puts "\n"


#  BOOKS IN LIBRARY ---------------------------------------------> 
# clientcheckout_one = .new(name: "walin", address: "out", bid: 33)
# clientcheckout_two = user.new(name: "walin", address: "out", bid: 33)
# clientcheckin_one = user.new(name: "walin", address: "out", bid: 33)
# clientcheckin_two = user.new(name: "walin", address: "out", bid: 33)


# def initialize(allbooks:, borrowedbooks:, availablebooks:)
#  = Library.new(theif, )
# assigned books 
# mark = Book.new("mark", "keane")
# # p mark.man_name
# # p mark
# trip = Visit.new("venice", mark)
