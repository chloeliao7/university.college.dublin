

class user
	attr_accessor :name, :address, :bid
  def initialize(name:, address:, bid:)
    @name = name
    @address = address 
    @bid = bid
	end

	def name?
    @title.to_s == 'harryportter'
  end
  
	def address?
		if test
			@address.to_s? == "12025"
			return true
		end
	end
	
  def bid?
    @bid.to_i == 20
	end

	def bookborrowdetails_arr=(name_array)
		@name = name_array[1]
		@address = name_array[2]
		@bid = name_array[3]
	end

	def bookborrowdetails_arr
		"Person: " + @name + @address + @bid
	end

	def printallborrowers_details 
		puts "#{@name}, #{@address}, #{@bid}"
	end

end
