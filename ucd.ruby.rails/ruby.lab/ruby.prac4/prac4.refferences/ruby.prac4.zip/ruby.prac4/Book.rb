class Book
  
  attr_accessor :title, :author, :uid, :page, :markbook

  def initialize(title:, author:, uid:, page:, markbook:)
    @title = title
    @author = author 
    @uid = uid
    @page = page
    @markbook = markbook
  end

  def printallbooks_details 
		puts "#{@title}, #{@author}, #{@uid}, #{@page}, #{@markbook}"
  end
  
  # def booksystem_arr
	# 	"Book: " + @title + @author + @uid + @page + @markbook
  # end
  
	# def booksystem_arr=(book_array)
	# 	@title = book_array[1]
	# 	@author = book_array[2]
	# 	@uid = book_array[3]
	# 	@page = book_array[4]
	# 	@markbook = book_array[5]
  # end

  def title?
    @title.to_s == 'harryportter'
  end
  
  def author?
    @author.to_s == 'markbookMurphy'
	end
	
  def uid?
    @author.to_i == 100000
	end
	
  def page?
    @author.to_i == 50
	end
	
  def markbook?
    @author.to_s == "P: there.will.be.light"
  end
  
end